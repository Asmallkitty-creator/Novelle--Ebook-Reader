# Novelle v2

Offline ebook reader (EPUB, PDF, TXT, HTML) built with Capacitor.

- `src/index.html` – the whole app (generated from `dev/`)
- `native/` – Android folder-scan plugin (Storage Access Framework) + launcher icons; copied into the Android project automatically after `cap sync` by `scripts/post-sync.js`
- `assets/icon-only.png` – app icon source

Upload this zip to the GitHub repo as `novelle-android.zip` (replace the old one) and the build workflow does the rest.
