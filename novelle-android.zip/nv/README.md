# Novelle

Offline ebook reader (EPUB, PDF, TXT, HTML) built with Capacitor.

## Updating without reinstalling
Use `novelle.yml` (the only workflow you need). Every push of a new `novelle-android.zip` builds the app,
signs it with the same key every time, and publishes it as a GitHub Release. The app then offers the update
itself: About -> Check for updates.

- `src/index.html` - the whole app (generated from `dev/`)
- `native/` - Android plugins (folder scan, self-update) + launcher icons, copied in by `scripts/post-sync.js`
