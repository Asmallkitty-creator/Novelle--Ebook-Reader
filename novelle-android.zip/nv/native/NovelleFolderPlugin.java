package com.novelle.reader;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.util.Base64;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

@CapacitorPlugin(name = "NovelleFolder")
public class NovelleFolderPlugin extends Plugin {

    @PluginMethod
    public void pickFolder(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(call, i, "pickResult");
    }

    @ActivityCallback
    private void pickResult(PluginCall call, ActivityResult r) {
        if (call == null) return;
        if (r.getResultCode() != Activity.RESULT_OK || r.getData() == null || r.getData().getData() == null) {
            call.reject("cancelled");
            return;
        }
        Uri u = r.getData().getData();
        boolean writable = false;
        try {
            getContext().getContentResolver().takePersistableUriPermission(u,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            writable = true;
        } catch (Exception e1) {
            try {
                getContext().getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
        }
        String id = DocumentsContract.getTreeDocumentId(u);
        String name = id.contains(":") ? id.substring(id.indexOf(':') + 1) : id;
        if (name.isEmpty()) name = "Storage";
        JSObject o = new JSObject();
        o.put("uri", u.toString());
        o.put("name", name);
        o.put("writable", writable);
        call.resolve(o);
    }

    @PluginMethod
    public void scan(PluginCall call) {
        String tree = call.getString("uri");
        if (tree == null) { call.reject("no uri"); return; }
        Uri treeUri = Uri.parse(tree);
        JSArray out = new JSArray();
        try {
            walk(treeUri, DocumentsContract.getTreeDocumentId(treeUri), out, 0);
        } catch (Exception e) {
            call.reject(String.valueOf(e));
            return;
        }
        JSObject o = new JSObject();
        o.put("files", out);
        call.resolve(o);
    }

    private void walk(Uri tree, String docId, JSArray out, int depth) {
        if (depth > 10) return;
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        Cursor c = null;
        try {
            c = getContext().getContentResolver().query(children, new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_SIZE,
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED}, null, null, null);
            if (c == null) return;
            while (c.moveToNext()) {
                String id = c.getString(0);
                String name = c.getString(1);
                String mime = c.getString(2);
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    walk(tree, id, out, depth + 1);
                    continue;
                }
                String l = name == null ? "" : name.toLowerCase();
                if (l.endsWith(".epub") || l.endsWith(".pdf") || l.endsWith(".txt") || l.endsWith(".html") || l.endsWith(".htm")) {
                    JSObject f = new JSObject();
                    f.put("uri", DocumentsContract.buildDocumentUriUsingTree(tree, id).toString());
                    f.put("name", name);
                    f.put("size", c.getLong(3));
                    f.put("modified", c.getLong(4));
                    out.put(f);
                }
            }
        } finally {
            if (c != null) c.close();
        }
    }

    @PluginMethod
    public void read(PluginCall call) {
        try {
            Uri u = Uri.parse(call.getString("uri"));
            long off = call.getData().optLong("offset", 0);
            int len = call.getData().optInt("length", 3 * 1024 * 1024);
            byte[] buf;
            int n = 0;
            long size = -1;
            try {
                ParcelFileDescriptor pfd = getContext().getContentResolver().openFileDescriptor(u, "r");
                try {
                    FileInputStream in = new FileInputStream(pfd.getFileDescriptor());
                    FileChannel ch = in.getChannel();
                    size = ch.size();
                    long left = Math.max(0, size - off);
                    ByteBuffer bb = ByteBuffer.allocate((int) Math.min((long) len, left));
                    ch.position(off);
                    while (bb.hasRemaining() && ch.read(bb) > 0) { }
                    buf = bb.array();
                    n = bb.position();
                } finally {
                    pfd.close();
                }
            } catch (Exception seekFail) {
                InputStream in = getContext().getContentResolver().openInputStream(u);
                long skipped = 0;
                while (skipped < off) {
                    long s = in.skip(off - skipped);
                    if (s <= 0) break;
                    skipped += s;
                }
                buf = new byte[len];
                int r;
                while (n < len && (r = in.read(buf, n, len - n)) > 0) n += r;
                in.close();
            }
            JSObject o = new JSObject();
            o.put("data", Base64.encodeToString(buf, 0, n, Base64.NO_WRAP));
            o.put("size", size);
            call.resolve(o);
        } catch (Exception e) {
            call.reject(String.valueOf(e));
        }
    }

    @PluginMethod
    public void deleteFile(PluginCall call) {
        try {
            Uri u = Uri.parse(call.getString("uri"));
            boolean ok = DocumentsContract.deleteDocument(getContext().getContentResolver(), u);
            if (ok) call.resolve(); else call.reject("failed");
        } catch (SecurityException e) {
            call.reject("permission");
        } catch (Exception e) {
            call.reject(String.valueOf(e));
        }
    }
}
