package com.novelle.reader;

import android.content.Context;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.PopupMenu;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    private ActionMode noop;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(NovelleFolderPlugin.class);
        super.onCreate(savedInstanceState);
    }

    // Hide Android's own floating copy/paste bubble. Novelle shows its own
    // toolbar (highlight, note, dictionary, copy, share) so the two never overlap.
    @Override
    public ActionMode onWindowStartingActionMode(ActionMode.Callback callback, int type) {
        if (type == ActionMode.TYPE_FLOATING) {
            try {
                if (noop == null) noop = new NoopActionMode(this);
                return noop;
            } catch (Exception ignored) { }
        }
        return super.onWindowStartingActionMode(callback, type);
    }

    static class NoopActionMode extends ActionMode {
        private final Context ctx;
        private final Menu menu;

        NoopActionMode(Context c) {
            ctx = c;
            menu = new PopupMenu(c, new View(c)).getMenu();
        }

        @Override public void setTitle(CharSequence t) { }
        @Override public void setTitle(int r) { }
        @Override public void setSubtitle(CharSequence t) { }
        @Override public void setSubtitle(int r) { }
        @Override public void setCustomView(View v) { }
        @Override public void invalidate() { }
        @Override public void finish() { }
        @Override public Menu getMenu() { return menu; }
        @Override public CharSequence getTitle() { return null; }
        @Override public CharSequence getSubtitle() { return null; }
        @Override public View getCustomView() { return null; }
        @Override public MenuInflater getMenuInflater() { return new MenuInflater(ctx); }
        @Override public void invalidateContentRect() { }
        @Override public void hide(long duration) { }
        @Override public void onWindowFocusChanged(boolean hasWindowFocus) { }
    }
}
