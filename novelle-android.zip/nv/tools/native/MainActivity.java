package com.novelle.reader;

import android.os.Bundle;
import android.view.KeyEvent;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  public static boolean volKeys = false;

  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(FolderScanPlugin.class);
    super.onCreate(savedInstanceState);
  }

  @Override
  public boolean dispatchKeyEvent(KeyEvent e) {
    int k = e.getKeyCode();
    if (volKeys && (k == KeyEvent.KEYCODE_VOLUME_UP || k == KeyEvent.KEYCODE_VOLUME_DOWN)) {
      if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) {
        final int d = k == KeyEvent.KEYCODE_VOLUME_UP ? -1 : 1;
        getBridge().getWebView().post(() ->
          getBridge().getWebView().evaluateJavascript("window.nvVol&&window.nvVol(" + d + ")", null));
      }
      return true;
    }
    return super.dispatchKeyEvent(e);
  }
}
