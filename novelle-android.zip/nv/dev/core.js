'use strict';
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const IC={
search:'<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',plus:'<path d="M12 5v14M5 12h14"/>',back:'<path d="M15 5l-7 7 7 7"/>',
right:'<path d="M5 12h14M13 6l6 6-6 6"/>',chev:'<path d="M9 6l6 6-6 6"/>',dots:'<circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/>',
home:'<path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',book:'<path d="M12 6c-2-1.5-5-2-9-2v14c4 0 7 .5 9 2 2-1.5 5-2 9-2V4c-4 0-7 .5-9 2zM12 6v14"/>',
compass:'<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',layers:'<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 12.5l9 5 9-5M3 17l9 5 9-5"/>',
user:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',heart:'<path d="M12 20s-8-5-8-11a4.5 4.5 0 0 1 8-2.5A4.5 4.5 0 0 1 20 9c0 6-8 11-8 11z"/>',
bm:'<path d="M6 3h12v18l-6-4-6 4z"/>',check:'<path d="M5 12.5l4.5 4.5L19 7.5"/>',clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
star:'<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',flame:'<path d="M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z"/>',
sparkle:'<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7z"/>',
grid:'<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
list:'<path d="M8 6h12M8 12h12M8 18h12"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/>',
panel:'<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M10 4v16"/>',filter:'<path d="M4 5h16l-6 8v6l-4-2v-4z"/>',
gear:'<circle cx="12" cy="12" r="3"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
palette:'<path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2-.6-1.2.2-2.5 1.6-2.5H17a4 4 0 0 0 4-4c0-5-4-9.5-9-9.5z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="15" cy="7.5" r="1"/>',
cloud:'<path d="M7 18a4.5 4.5 0 0 1-.5-9 6 6 0 0 1 11.5 1.5A3.8 3.8 0 0 1 17.5 18z"/>',chart:'<path d="M5 20V10M12 20V4M19 20v-7"/>',
shield:'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M8.5 12l2.5 2.5L16 9.5"/>',sliders:'<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>',
info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>',pin:'<path d="M9 3h6l-1 6 3 3H7l3-3zM12 12v9"/>',tag:'<path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.5" cy="8.5" r="1.2"/>',
folder:'<path d="M3 6a1 1 0 0 1 1-1h5l2 2h8a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/>',pen:'<path d="M4 20l1-4L16.5 4.5a2 2 0 0 1 3 3L8 19z"/>',
upload:'<path d="M12 16V4M7 9l5-5 5 5M5 20h14"/>',download:'<path d="M12 4v12M7 11l5 5 5-5M5 20h14"/>',trash:'<path d="M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13"/>',
x:'<path d="M6 6l12 12M18 6L6 18"/>',share:'<circle cx="6" cy="12" r="2.5"/><circle cx="17" cy="6" r="2.5"/><circle cx="17" cy="18" r="2.5"/><path d="M8.2 10.8l6.6-3.6M8.2 13.2l6.6 3.6"/>',
quote:'<path d="M5 18v-6a5 5 0 0 1 5-5M13 18v-6a5 5 0 0 1 5-5"/>',moon:'<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
notes:'<path d="M5 4h14v16H5z"/><path d="M8 9h8M8 13h8M8 17h4"/>',merge:'<circle cx="6" cy="5" r="2"/><circle cx="18" cy="5" r="2"/><circle cx="12" cy="19" r="2"/><path d="M6 7c0 6 6 6 6 10M18 7c0 6-6 6-6 10"/>',
updown:'<path d="M8 4v16M4 8l4-4 4 4M16 20V4M12 16l4 4 4-4"/>',castle:'<path d="M4 21V9h3V6h2v3h2V6h2v3h2V6h2v3h3v12zM10 21v-5a2 2 0 0 1 4 0v5"/>',
planet:'<circle cx="12" cy="12" r="5"/><path d="M3 15c0-3 4-6 9-6s9 3 9 6c0 2-3 3-6 3"/>',columns:'<path d="M4 8l8-4 8 4zM6 10v8M10 10v8M14 10v8M18 10v8M4 20h16"/>',
arch:'<path d="M3 20V9a9 9 0 0 1 18 0v11M8 20v-6a4 4 0 0 1 8 0v6"/>',head:'<path d="M8 4c-3 1-4 5-3 8l-1 3 3 1 1 4h7l1-6c3-3 1-9-4-10-1-.2-3-.2-4 0z"/>',
leaf:'<path d="M5 19C5 9 11 4 20 4c0 9-5 15-15 15zM5 19c3-5 6-8 10-10"/>',eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
play:'<path d="M7 4l13 8-13 8z"/>',headphones:'<path d="M4 15v-3a8 8 0 0 1 16 0v3"/><rect x="3" y="14" width="4" height="7" rx="1.5"/><rect x="17" y="14" width="4" height="7" rx="1.5"/>',
type:'<path d="M4 19l5-14 5 14M6.2 14h5.6M16 19v-7M14 13.5h4"/>',copy:'<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
dice:'<rect x="4" y="4" width="16" height="16" rx="3"/><circle cx="9" cy="9" r="1"/><circle cx="15" cy="15" r="1"/><circle cx="15" cy="9" r="1"/><circle cx="9" cy="15" r="1"/>',
trend:'<path d="M3 17l6-6 4 4 8-8M15 7h6v6"/>',users:'<circle cx="9" cy="8" r="3.5"/><path d="M2 20c0-4 3-6 7-6s7 2 7 6M16 4.5a3.5 3.5 0 0 1 0 7M18 14c2.5.7 4 2.5 4 6"/>'};
const ic=(k,c='')=>`<svg class="ic ${c}" viewBox="0 0 24 24">${IC[k]||''}</svg>`;
let _bn=0;const banner=()=>{const n=++_bn;return `<svg class="banner" viewBox="0 0 400 150" preserveAspectRatio="xMaxYMid slice"><defs><linearGradient id="sk${n}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1a0a3b"/><stop offset=".62" stop-color="#5b1f88"/><stop offset="1" stop-color="#e0597a"/></linearGradient><radialGradient id="mn${n}"><stop offset="0" stop-color="#ffd9aa"/><stop offset="1" stop-color="#ff8f8f" stop-opacity="0"/></radialGradient></defs><rect width="400" height="150" fill="url(#sk${n})"/><g fill="#fff" opacity=".7"><circle cx="40" cy="22" r="1"/><circle cx="130" cy="40" r="1.2"/><circle cx="210" cy="18" r="1"/><circle cx="260" cy="44" r=".9"/><circle cx="90" cy="64" r=".8"/></g><circle cx="318" cy="54" r="30" fill="url(#mn${n})" opacity=".55"/><circle cx="318" cy="54" r="12" fill="#ffd9b0"/><path d="M0 112L60 82l50 20 60-34 60 30 60-24 60 26 50-18v66H0z" fill="#2b1054" opacity=".92"/><path d="M0 130l80-26 70 18 90-28 90 26 70-14v44H0z" fill="#150a2e"/><path fill="#0b061d" d="M262 112V76h5v-9l3-5 3 5v9h4V62l3-6 3 6v14h5v-7l3-4 3 4v7h4V58l3-7 3 7v18h5v36z"/></svg>`};
/* ---------- settings ---------- */
const DEF={at:'midnight',rt:'night',ff:'lit',fs:19,lh:1.6,mg:1,just:1,an:'curl',md:'paginated',view:'grid',sort:'opened',zones:1,dim:0,goal:12,rs:0,days:{},cbg:'#1b1530',cfg:'#e8dff5',ic:0,name:'Reader',folder:null,auto:1};
let S=Object.assign({},DEF);try{Object.assign(S,JSON.parse(localStorage.getItem('ns2')||'{}'))}catch(e){}
if(Array.isArray(S.days))S.days={};
const save=()=>{try{localStorage.setItem('ns2',JSON.stringify(S))}catch(e){}};
let COL=[];try{COL=JSON.parse(localStorage.getItem('nc2')||'null')||Object.entries(JSON.parse(localStorage.getItem('nc')||'{}')).map(([n,ids])=>({id:'c'+Math.random().toString(36).slice(2,8),name:n,ids,pin:0}))}catch(e){COL=[]}
const saveC=()=>{try{localStorage.setItem('nc2',JSON.stringify(COL))}catch(e){}};
/* ---------- storage ---------- */
const dbp=new Promise((res,rej)=>{const q=indexedDB.open('novelle',2);q.onupgradeneeded=()=>{const d=q.result;if(!d.objectStoreNames.contains('b'))d.createObjectStore('b',{keyPath:'id'});if(!d.objectStoreNames.contains('f'))d.createObjectStore('f')};q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)});
const tx=async(st,m,f)=>{const d=await dbp;return new Promise((res,rej)=>{const t=d.transaction(st,m);let r;try{r=f(t.objectStore(st))}catch(e){rej(e);return}t.oncomplete=()=>res(r&&r.result);t.onerror=t.onabort=()=>rej(t.error)})};
const dbPut=b=>tx('b','readwrite',s=>s.put(b)),dbAll=()=>tx('b','readonly',s=>s.getAll()),dbDel=id=>tx('b','readwrite',s=>s.delete(id));
const fPut=(id,d)=>tx('f','readwrite',s=>s.put(d,id)),fGet=id=>tx('f','readonly',s=>s.get(id)),fDel=id=>tx('f','readwrite',s=>s.delete(id));
let books=[];const _t={};
const saveBook=(b,now)=>{clearTimeout(_t[b.id]);if(now)return dbPut(b).catch(()=>{});_t[b.id]=setTimeout(()=>dbPut(b).catch(()=>{}),500)};
async function loadBooks(){const r=await dbAll();for(const b of r){if(b.data){await fPut(b.id,b.data);delete b.data;await dbPut(b)}
b.cats=b.cats||[];b.tags=b.tags||[];b.series=b.series||'';b.fav=b.fav||0;b.pct=b.pct||0;b.hl=(b.hl||[]).filter(h=>'ci' in h);b.marks=(b.marks||[]).filter(m=>'ci' in m);b.pos=b.pos&&'ci' in b.pos?b.pos:null;b.size=b.size||0;b.opened=b.opened||0}
books=r}
/* ---------- helpers ---------- */
const norm=s=>(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const catOf=b=>b.cats[0]||'Uncategorized';
const FM=['epub','pdf','txt','html','htm'];
function thumbFromBlob(blob){return new Promise(r=>{const u=URL.createObjectURL(blob),i=new Image();i.onload=()=>{const c=document.createElement('canvas');c.width=240;c.height=Math.round(240*i.height/i.width)||360;c.getContext('2d').drawImage(i,0,0,c.width,c.height);URL.revokeObjectURL(u);r(c.toDataURL('image/jpeg',.82))};i.onerror=()=>{URL.revokeObjectURL(u);r(null)};i.src=u})}
function gen(t,a){const c=document.createElement('canvas');c.width=240;c.height=360;const x=c.getContext('2d'),h=[...t].reduce((s,ch)=>s+ch.charCodeAt(0),0)%360,g=x.createLinearGradient(0,0,240,360);
g.addColorStop(0,`hsl(${(h+260)%360},55%,30%)`);g.addColorStop(1,`hsl(${(h+300)%360},60%,12%)`);x.fillStyle=g;x.fillRect(0,0,240,360);x.strokeStyle='#ffffff40';x.lineWidth=2;x.strokeRect(12,12,216,336);
x.fillStyle='#fff';x.textAlign='center';x.font='bold 24px Georgia,serif';let y=120,l='';const ws=(t||'').split(' ');for(const w of ws){if(x.measureText(l+w).width>190){x.fillText(l.trim(),120,y);y+=30;l=''}l+=w+' '}x.fillText(l.trim(),120,y);x.font='15px Georgia,serif';x.globalAlpha=.75;x.fillText((a||'').slice(0,28),120,Math.min(330,y+44));return c.toDataURL('image/jpeg',.85)}
/* ---------- EPUB ---------- */
const dpar=new DOMParser(),xml=s=>dpar.parseFromString(s,'application/xml');
const dirn=p=>p.includes('/')?p.slice(0,p.lastIndexOf('/')+1):'';
const resolve=(base,rel)=>{rel=rel.split('#')[0].split('?')[0];try{rel=decodeURIComponent(rel)}catch(e){}const o=[];for(const s of (dirn(base)+rel).split('/')){if(s=='..')o.pop();else if(s&&s!='.')o.push(s)}return o.join('/')};
const zf=(zip,p)=>zip.file(p)||zip.file(p.replace(/%20/g,' '))||Object.values(zip.files).find(f=>f.name.toLowerCase()==p.toLowerCase());
const ztxt=async(zip,p)=>{const f=zf(zip,p);return f?f.async('string'):null};
const tn=(n,t)=>[...n.getElementsByTagName(t)],t1=(n,t)=>n.getElementsByTagName(t)[0];
async function openEpub(buf,light){
const zip=await JSZip.loadAsync(buf);
const cont=xml(await ztxt(zip,'META-INF/container.xml')),opfP=t1(cont,'rootfile').getAttribute('full-path'),opf=xml(await ztxt(zip,opfP));
const man={};tn(opf,'item').forEach(i=>man[i.getAttribute('id')]={path:resolve(opfP,i.getAttribute('href')||''),type:i.getAttribute('media-type')||'',props:i.getAttribute('properties')||''});
const spine=tn(opf,'itemref').map(r=>man[r.getAttribute('idref')]).filter(m=>m&&/html|xml/.test(m.type)&&!/ncx/.test(m.type));
const metas=tn(opf,'meta'),mt=k=>{const e=t1(opf,k);return e?e.textContent.trim():''};
const meta={title:mt('dc:title'),author:tn(opf,'dc:creator').map(e=>e.textContent.trim()).filter(Boolean).join(', '),cats:tn(opf,'dc:subject').map(e=>e.textContent.trim()).filter(Boolean).slice(0,4),lang:mt('dc:language'),
series:(metas.find(m=>m.getAttribute('name')=='calibre:series')||{getAttribute:()=>''}).getAttribute('content')};
const cid=(metas.find(m=>m.getAttribute('name')=='cover')||{getAttribute:()=>''}).getAttribute('content');
let cov=man[cid]||Object.values(man).find(m=>/cover-image/.test(m.props))||Object.values(man).find(m=>/image/.test(m.type)&&/cover/i.test(m.path));
const getCover=async()=>{if(!cov||!/image/.test(cov.type)){const f=spine[0]&&await ztxt(zip,spine[0].path);if(f){const m=f.match(/(?:src|href)=["']([^"']+\.(?:jpe?g|png|gif|webp))["']/i);if(m)cov={path:resolve(spine[0].path,m[1]),type:'image/jpeg'}}}
if(!cov)return null;const f=zf(zip,cov.path);if(!f)return null;return thumbFromBlob(await f.async('blob'))};
if(light)return{meta,getCover};
const idx={};spine.forEach((s,i)=>idx[s.path]=i);
const toc=[];
const navI=Object.values(man).find(m=>/\bnav\b/.test(m.props)),ncxI=Object.values(man).find(m=>/ncx/.test(m.type));
const push=(label,href,d,base)=>{const p=resolve(base,href),ci=idx[p];if(ci!=null&&label)toc.push({label:label.replace(/\s+/g,' ').trim(),ci,frag:(href.split('#')[1]||''),d})};
try{if(navI){const nd=dpar.parseFromString(await ztxt(zip,navI.path),'text/html');const nav=nd.querySelector('nav[epub\\:type~="toc"]')||nd.querySelector('nav');
const walk=(ol,d)=>{[...ol.children].forEach(li=>{const a=li.querySelector(':scope>a,:scope>span>a');if(a)push(a.textContent,a.getAttribute('href')||'',d,navI.path);const sub=li.querySelector(':scope>ol');if(sub)walk(sub,d+1)})};const ol=nav&&nav.querySelector('ol');if(ol)walk(ol,0)}
else if(ncxI){const nx=xml(await ztxt(zip,ncxI.path));const walk=(el,d)=>[...el.children].filter(c=>c.tagName=='navPoint').forEach(np=>{const l=t1(np,'text'),c=t1(np,'content');if(l&&c)push(l.textContent,c.getAttribute('src')||'',d,ncxI.path);walk(np,d+1)});const nm=t1(nx,'navMap');if(nm)walk(nm,0)}}catch(e){console.warn('toc',e)}
const wts=spine.map(s=>{const f=zf(zip,s.path);return(f&&f._data&&f._data.uncompressedSize)||1000});
const urls=new Map();
const blobUrl=async p=>{if(urls.has(p))return urls.get(p);const f=zf(zip,p);if(!f)return'';const b=await f.async('blob'),u=URL.createObjectURL(b.type?b:new Blob([b],{type:'image/'+(p.split('.').pop()||'jpeg').replace('jpg','jpeg')}));urls.set(p,u);return u};
const html=async ci=>{const p=spine[ci].path,s=await ztxt(zip,p)||'';let doc=dpar.parseFromString(s,'application/xhtml+xml');if(doc.getElementsByTagName('parsererror').length)doc=dpar.parseFromString(s,'text/html');
const body=doc.body||t1(doc,'body');if(!body)return'';
body.querySelectorAll('script,style,link,meta,title,iframe,object').forEach(e=>e.remove());
const XL='http://www.w3.org/1999/xlink';
for(const im of body.querySelectorAll('img,image')){const a=im.getAttribute('src')||im.getAttribute('href')||im.getAttributeNS(XL,'href');if(a&&!/^(data:|https?:)/.test(a)){const u=await blobUrl(resolve(p,a));im.removeAttribute('src');im.removeAttribute('href');im.removeAttributeNS(XL,'href');im.setAttribute(im.localName=='image'?'href':'src',u)}im.removeAttribute('width');im.removeAttribute('height');im.removeAttribute('style')}
body.querySelectorAll('[style]').forEach(e=>{const m=(e.getAttribute('style')||'').match(/text-align:\s*(center|right)/);m?e.setAttribute('style','text-align:'+m[1]):e.removeAttribute('style')});
body.querySelectorAll('a[href]').forEach(a=>{const h=a.getAttribute('href');if(/^https?:/.test(h)){a.removeAttribute('href')}else{a.setAttribute('data-ih',h.startsWith('#')?p+h:resolve(p,h)+(h.includes('#')?'#'+h.split('#')[1]:''));a.removeAttribute('href')}});
const n=document.importNode(body,true);return n.innerHTML};
return{kind:'flow',n:spine.length,wts,toc,meta,getCover,html,spineIdx:idx,spinePath:i=>spine[i].path,close(){urls.forEach(u=>URL.revokeObjectURL(u));urls.clear()}}}
/* ---------- TXT / HTML ---------- */
function flowFromText(buf,fmt,name){const t=new TextDecoder('utf-8').decode(buf);let parts=[];
if(fmt=='txt'){const paras=t.split(/\r?\n\s*\r?\n|\r?\n/).filter(x=>x.trim()),chunks=[];let cur=[],len=0;for(const p of paras){cur.push('<p>'+esc(p.trim())+'</p>');len+=p.length;if(len>14000){chunks.push(cur.join(''));cur=[];len=0}}if(cur.length)chunks.push(cur.join(''));parts=chunks.length?chunks:['<p></p>']}
else{const d=dpar.parseFromString(t,'text/html');d.querySelectorAll('script,style,link,meta,iframe').forEach(e=>e.remove());d.querySelectorAll('[style]').forEach(e=>e.removeAttribute('style'));parts=[d.body.innerHTML]}
const title=name.replace(/\.[^.]+$/,'');
return{kind:'flow',n:parts.length,wts:parts.map(p=>p.length),toc:parts.length>1?parts.map((p,i)=>({label:'Part '+(i+1),ci:i,frag:'',d:0})):[],meta:{title,author:'',cats:[]},getCover:async()=>null,html:async ci=>parts[ci],spineIdx:{},spinePath:i=>'',close(){}}}
/* ---------- PDF ---------- */
async function openPdf(buf){if(typeof pdfjsLib=='undefined')throw new Error('PDF engine not loaded');if(!pdfjsLib.GlobalWorkerOptions.workerSrc)pdfjsLib.GlobalWorkerOptions.workerSrc='lib/pdf.worker.min.js';
const doc=await pdfjsLib.getDocument({data:new Uint8Array(buf.slice(0))}).promise;let info={};try{info=(await doc.getMetadata()).info||{}}catch(e){}
const toc=[];try{const o=await doc.getOutline()||[];const walk=async(l,d)=>{for(const c of l){try{const dest=typeof c.dest=='string'?await doc.getDestination(c.dest):c.dest;const pi=await doc.getPageIndex(dest[0]);toc.push({label:c.title,ci:pi,frag:'',d})}catch(e){}if(c.items)await walk(c.items,d+1)}};await walk(o,0)}catch(e){}
return{kind:'pdf',n:doc.numPages,wts:Array(doc.numPages).fill(1),toc,doc,meta:{title:info.Title||'',author:info.Author||'',cats:[]},
async getCover(){const p=await doc.getPage(1),v=p.getViewport({scale:1}),s=240/v.width,c=document.createElement('canvas');c.width=240;c.height=Math.round(v.height*s);await p.render({canvasContext:c.getContext('2d'),viewport:p.getViewport({scale:s})}).promise;return c.toDataURL('image/jpeg',.82)},close(){try{doc.destroy()}catch(e){}}}}
/* ---------- native folder bridge ---------- */
const plug=()=>{try{return window.Capacitor&&window.Capacitor.isNativePlatform&&window.Capacitor.isNativePlatform()?(Capacitor.Plugins.NovelleFolder||(Capacitor.registerPlugin&&Capacitor.registerPlugin('NovelleFolder'))):null}catch(e){return null}};
async function safRead(uri,size){const P=plug(),parts=[],CH=3*1024*1024;let off=0;
for(;;){const r=await P.read({uri,offset:off,length:CH});const ab=await(await fetch('data:application/octet-stream;base64,'+r.data)).arrayBuffer();parts.push(ab);off+=ab.byteLength;if(!ab.byteLength||(r.size>0&&off>=r.size)||(size&&off>=size))break}
const out=new Uint8Array(off);let p=0;for(const a of parts){out.set(new Uint8Array(a),p);p+=a.byteLength}return out.buffer}
const bookBytes=async b=>b.uri?safRead(b.uri,b.size):fGet(b.id);
/* ---------- import ---------- */
async function readMeta(fmt,buf,name){const base=name.replace(/\.[^.]+$/,'');let m={title:'',author:'',cats:[],series:'',lang:''},cover=null;
try{if(fmt=='epub'){const e=await openEpub(buf,true);m=Object.assign(m,e.meta);try{cover=await e.getCover()}catch(x){}}
else if(fmt=='pdf'){const p=await openPdf(buf);m=Object.assign(m,p.meta);try{cover=await p.getCover()}catch(x){}p.close()}}catch(e){console.warn('meta',name,e)}
m.title=(m.title||base).trim();m.cats=[...new Set(m.cats.map(c=>c.replace(/\s+/g,' ').slice(0,28)))];return{...m,cover}}
async function ingest(name,size,getBuf,uri){const fmt=name.split('.').pop().toLowerCase();if(!FM.includes(fmt))return 0;const id=name+'|'+size;if(books.some(b=>b.id==id))return 0;
const buf=await getBuf(),m=await readMeta(fmt,buf,name);
const b={id,title:m.title,author:m.author,fmt,size,cover:m.cover||gen(m.title,m.author),cats:m.cats,series:m.series||'',tags:[],added:Date.now(),opened:0,pct:0,pos:null,fav:0,marks:[],hl:[],uri:uri||null,lang:m.lang||''};
if(!uri)await fPut(id,buf);await dbPut(b);books.push(b);return 1}
