/* ================= READER ================= */
const RT={night:{n:'Night',bg:'#120c24',fg:'#e9e1d6',ac:'#c58bff'},sepia:{n:'Sepia',bg:'#e9d8b4',fg:'#4a3a22',ac:'#8a4a12'},paper:{n:'Paper',bg:'#f4ecd8',fg:'#3b3226',ac:'#7a3f12'},
warm:{n:'Warm paper',bg:'#f7e9d0',fg:'#43331f',ac:'#9a4a1a'},white:{n:'White',bg:'#ffffff',fg:'#16121c',ac:'#6b32c9'},dim:{n:'Dim',bg:'#2a2a2f',fg:'#c8c8cc',ac:'#b79bff'},oled:{n:'OLED',bg:'#000000',fg:'#b8b8b8',ac:'#a77bff'},custom:{n:'Custom'}};
const FONTS={lit:['Literata','Literata,"Noto Serif",Georgia,serif'],geo:['Georgia','Georgia,"Noto Serif",serif'],pal:['Palatino','"Palatino Linotype",Palatino,"Book Antiqua","Noto Serif",serif'],sans:['Sans','system-ui,Roboto,"Noto Sans",sans-serif'],mono:['Mono','ui-monospace,"Noto Sans Mono",monospace']};
const ANIMS=[['curl','Page curl'],['slide','Slide'],['cover','Cover'],['fade','Fade'],['flip','3D flip'],['none','None']];
const HCOL=['#ffd15c','#ff7fb4','#b36cff','#5cb2ff','#5ce08a'];
const R={b:null,bk:null,pos:null,cur:null,turning:null,pg:{},hc:new Map(),pdfc:new Map(),cum:[0],tot:1,mp:0,mw:0,ui:false};let G={};
const rtheme=()=>S.rt=='custom'?{bg:S.cbg,fg:S.cfg,ac:'#b78bff'}:(RT[S.rt]||RT.night);
const hexRgb=h=>{h=h.replace('#','');if(h.length==3)h=[...h].map(c=>c+c).join('');return[0,2,4].map(i=>parseInt(h.substr(i,2),16))};
const isDark=h=>{const[r,g,b]=hexRgb(h);return(r*299+g*587+b*114)/1000<110};
function applyVars(){const t=rtheme(),st=$('#stage');st.style.setProperty('--pbg',t.bg);st.style.setProperty('--pfg',t.fg);st.style.setProperty('--pac',t.ac);
st.style.setProperty('--rf',FONTS[S.ff][1]);st.style.setProperty('--rfs',S.fs+'px');st.style.setProperty('--rlh',S.lh);st.style.setProperty('--rj',S.just?'justify':'left');
$('#dim').style.opacity=S.dim/100;
if(['paper','warm','sepia'].includes(S.rt)){const a=hexRgb(t.bg),b=[122,90,42],m=a.map((v,i)=>Math.round(v*.9+b[i]*.1));st.style.setProperty('--pbg',`radial-gradient(120% 90% at 30% 20%,${t.bg},rgb(${m})) ${t.bg}`)}}
function calcGeom(){const st=$('#stage'),W=st.clientWidth,H=st.clientHeight,px=[16,28,46][S.mg]??28,padT=34,padB=46;G={W,H,px,padT,padB,iw:Math.max(120,W-2*px),ih:Math.max(160,H-padT-padB),gap:2*px,stride:W};st.style.setProperty('--rih',G.ih+'px')}
const meas=document.createElement('div');meas.className='page flow';meas.style.cssText='visibility:hidden;pointer-events:none;z-index:0';
function colsEl(html,ci){const c=document.createElement('div');c.className='cols';c.style.cssText=`left:${G.px}px;top:${G.padT}px;width:${G.iw}px;height:${G.ih}px;column-width:${G.iw}px;column-gap:${G.gap}px`;c.innerHTML=html;if(ci!=null)applyHL(c,ci);return c}
async function htmlOf(ci){if(R.hc.has(ci))return R.hc.get(ci);const h=await R.bk.html(ci);R.hc.set(ci,h);if(R.hc.size>14)R.hc.delete(R.hc.keys().next().value);return h}
async function pagesOf(ci){if(R.bk.kind=='pdf')return 1;if(R.pg[ci])return R.pg[ci];const h=await htmlOf(ci);meas.style.width=G.W+'px';meas.style.height=G.H+'px';meas.innerHTML='';const c=colsEl(h);meas.append(c);
const n=Math.max(1,Math.round((c.scrollWidth+G.gap)/G.stride));R.pg[ci]=n;R.mp+=n;R.mw+=R.bk.wts[ci];meas.innerHTML='';return n}
async function fragPage(ci,frag){await pagesOf(ci);const h=await htmlOf(ci);meas.innerHTML='';const c=colsEl(h);meas.append(c);let e=null;try{e=c.querySelector('[id="'+frag.replace(/"/g,'')+'"],[name="'+frag.replace(/"/g,'')+'"]')}catch(x){}
const r=e?Math.floor((e.getBoundingClientRect().left-c.getBoundingClientRect().left)/G.stride):null;meas.innerHTML='';return r==null?null:Math.max(0,Math.min(R.pg[ci]-1,r))}
function textOff(root,node,off){const r=document.createRange();r.selectNodeContents(root);r.setEnd(node,off);return r.toString().length}
function applyHL(c,ci){const L=R.b.hl.filter(h=>h.ci==ci);if(!L.length)return;for(const h of L){const w=document.createTreeWalker(c,NodeFilter.SHOW_TEXT),nodes=[];let n,pos=0;
while(n=w.nextNode()){const l=n.nodeValue.length;if(pos+l>h.s&&pos<h.e)nodes.push([n,Math.max(0,h.s-pos),Math.min(l,h.e-pos)]);pos+=l;if(pos>=h.e)break}
for(const[nd,a,b]of nodes){const r=document.createRange();r.setStart(nd,a);r.setEnd(nd,b);const m=document.createElement('mark');m.className='h'+h.c+(h.note?' nt':'');m.dataset.id=h.id;try{r.surroundContents(m)}catch(e){}}}}
async function pdfCanvas(i){if(R.pdfc.has(i))return R.pdfc.get(i);const p=await R.bk.doc.getPage(i+1),v1=p.getViewport({scale:1}),dpr=Math.min(2,devicePixelRatio||1),s=Math.min(G.W/v1.width,G.H/v1.height),vp=p.getViewport({scale:s*dpr}),c=document.createElement('canvas');
c.width=vp.width;c.height=vp.height;c.style.width=vp.width/dpr+'px';c.style.height=vp.height/dpr+'px';await p.render({canvasContext:c.getContext('2d'),viewport:vp}).promise;R.pdfc.set(i,c);if(R.pdfc.size>6)R.pdfc.delete(R.pdfc.keys().next().value);return c}
async function pageEl(pos){const d=document.createElement('div');d.className='page '+(R.bk.kind=='pdf'?'pdf':'flow');d.style.cssText=`width:${G.W}px;height:${G.H}px`;
if(R.bk.kind=='pdf'){const cv=await pdfCanvas(pos.ci),c2=document.createElement('canvas');c2.width=cv.width;c2.height=cv.height;c2.style.width=cv.style.width;c2.style.height=cv.style.height;c2.getContext('2d').drawImage(cv,0,0);
const t=rtheme();c2.style.filter=isDark(t.bg)?'invert(.9) hue-rotate(180deg)':S.rt=='white'?'none':'sepia(.25)';d.append(c2);return d}
const c=colsEl(await htmlOf(pos.ci),pos.ci);c.style.transform=`translateX(${-pos.pi*G.stride}px)`;d.append(c);return d}
const nextPos=async p=>{const n=await pagesOf(p.ci);return p.pi+1<n?{ci:p.ci,pi:p.pi+1}:p.ci+1<R.bk.n?{ci:p.ci+1,pi:0}:null};
const prevPos=async p=>p.pi>0?{ci:p.ci,pi:p.pi-1}:p.ci>0?{ci:p.ci-1,pi:(await pagesOf(p.ci-1))-1}:null;
const curFr=()=>R.pos.pi/(R.pg[R.pos.ci]||1);
function overall(pos,pi){const n=R.pg[pos.ci]||1;return Math.min(1,(R.cum[pos.ci]+R.bk.wts[pos.ci]*((pi??pos.pi)/n))/R.tot)}
function chTitle(ci){let t='';for(const e of R.bk.toc)if(e.ci<=ci)t=e.label;return t||R.b.title}
function updateUI(){const p=overall(R.pos),est=R.bk.kind=='pdf'?R.bk.n:Math.max(1,Math.round(R.tot/(R.mw/Math.max(1,R.mp))||1)),pn=R.bk.kind=='pdf'?R.pos.ci+1:Math.min(est,Math.round(p*est)+1);
$('#fc').textContent=chTitle(R.pos.ci);$('#fp').textContent=`${pn} / ${est} · ${Math.round(p*100)}%`;$('#rsl').value=Math.round(p*1000);$('#rsl1').textContent=chTitle(R.pos.ci);$('#rsl2').textContent=`${pn} / ${est}  ${Math.round(p*100)}%`;
const mk=R.b.marks.some(m=>m.ci==R.pos.ci&&Math.abs(m.fr-curFr())<.5/(R.pg[R.pos.ci]||1));$('#rbm').innerHTML=ic('bm',mk?'f':'');R.b.pct=p;R.b.pos={ci:R.pos.ci,fr:curFr()};R.b.opened=R.b.opened||Date.now();saveBook(R.b)}
function setCur(el){const st=$('#stage');if(R.cur&&R.cur!==el)R.cur.remove();R.cur=el;el.style.zIndex=1;st.insertBefore(el,$('#foot'))}
async function showCurrent(){const sc=S.md=='scroll'&&R.bk.kind!='pdf';const el=sc?await scrollEl():await pageEl(R.pos);setCur(el);hideSel();await pagesOf(R.pos.ci);updateUI();prefetch()}
async function prefetch(){try{const n=await nextPos(R.pos);if(n){await pagesOf(n.ci);if(R.bk.kind=='pdf')pdfCanvas(n.ci)}const p=await prevPos(R.pos);if(p){await pagesOf(p.ci);if(R.bk.kind=='pdf')pdfCanvas(p.ci)}updateUI()}catch(e){}}
async function jump(t){if(R.turning)return;const ci=Math.max(0,Math.min(R.bk.n-1,t.ci)),n=await pagesOf(ci);let pi=Math.min(n-1,Math.max(0,Math.floor((t.fr||0)*n)));if(t.frag){const f=await fragPage(ci,t.frag);if(f!=null)pi=f}R.pos={ci,pi};await showCurrent()}
/* ---- scroll mode ---- */
async function scrollEl(){const d=document.createElement('div');d.className='page scr';d.style.cssText=`width:${G.W}px;height:${G.H}px;touch-action:pan-y`;const ci=R.pos.ci,c=document.createElement('div');c.className='cols';c.style.cssText='font:inherit';c.innerHTML=await htmlOf(ci);applyHL(c,ci);d.append(c);
d.insertAdjacentHTML('beforeend',`<div class="nx">${ci>0?'<button class="btn g sm" data-ch="-1">Previous chapter</button>':''}${ci+1<R.bk.n?'<button class="btn sm" data-ch="1">Next chapter</button>':''}</div>`);
d.onscroll=()=>{const fr=d.scrollTop/Math.max(1,d.scrollHeight-d.clientHeight);R.pg[ci]=1000;R.pos={ci,pi:Math.round(fr*999)};R.b.pct=overall(R.pos);R.b.pos={ci,fr};saveBook(R.b);const p=R.b.pct;$('#fp').textContent=Math.round(p*100)+'%';$('#rsl').value=Math.round(p*1000)};
d.onclick=e=>{const b=e.target.closest('[data-ch]');if(b){R.pos={ci:ci+ +b.dataset.ch,pi:0};R.pg={};showCurrent()}};
requestAnimationFrame(()=>{d.scrollTop=R.pos.pi/1000*(d.scrollHeight-d.clientHeight)||0});return d}
/* ---- page turning ---- */
function curlGeo(f,fy,ph){const{W,H}=G,phi=((fy/H)-.5)*.55*ph,nx=Math.cos(phi),ny=Math.sin(phi),side=(x,y)=>nx*(x-f)+ny*(y-fy),rect=[[0,0],[W,0],[W,H],[0,H]];
const clip=keepPos=>{const o=[];for(let i=0;i<4;i++){const a=rect[i],b=rect[(i+1)%4],sa=side(a[0],a[1]),sb=side(b[0],b[1]),ia=keepPos?sa>=0:sa<=0,ib=keepPos?sb>=0:sb<=0;if(ia)o.push(a);if(ia!==ib){const t=sa/(sa-sb);o.push([a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t])}}return o};
const d=nx*f+ny*fy;return{phi,keep:clip(false),curl:clip(true),m:[1-2*nx*nx,-2*nx*ny,-2*nx*ny,1-2*ny*ny,2*d*nx,2*d*ny]}}
const poly=a=>'polygon('+a.map(p=>p[0].toFixed(1)+'px '+p[1].toFixed(1)+'px').join(',')+')';
function frameCurl(T,p,fy){const{W,H}=G,f=T.dir>0?W*(1-p)-p*26:W*p-(1-p)*26,ph=Math.min(1,Math.min(p,1-p)*7),g=curlGeo(f,fy,ph),top=T.top;
top.style.clipPath=g.curl.length?(g.keep.length?poly(g.keep):'polygon(0 0,0 0,0 0)'):'none';
if(!g.curl.length||g.curl.length<3){T.fw.style.display='none';T.sw.style.display='none';return}
T.fw.style.display=T.sw.style.display='block';
const fl=T.flap;fl.style.transform=`matrix(${g.m.map(v=>v.toFixed(5)).join(',')})`;fl.style.clipPath=poly(g.curl);
const L=Math.max(30,W-f),[r,gg,b]=hexRgb(rtheme().bg);
T.fo.style.background=`linear-gradient(90deg,transparent ${f}px,rgba(0,0,0,.38) ${f}px,rgba(255,255,255,.12) ${f+L*.35}px,rgba(0,0,0,.2) ${W}px),linear-gradient(rgba(${r},${gg},${b},.5),rgba(${r},${gg},${b},.5))`;
T.sw.style.clipPath=poly(g.curl);T.strip.style.transform=`translate(${f}px,${fy}px) rotate(${g.phi}rad) translateY(${-1.5*H}px)`}
function frameOther(T,p){const{W}=G,d=T.dir,an=T.an,c=T.cur,t=T.tgt,top=T.top,und=T.under,pt=d>0?p:1-p;
if(an=='slide'){c.style.transform=`translateX(${-d*p*W}px)`;t.style.transform=`translateX(${d*(1-p)*W}px)`}
else if(an=='cover'){t.style.transform=`translateX(${d*(1-p)*W}px)`;t.style.boxShadow='0 0 30px #000b';c.style.transform=`translateX(${-d*p*W*.25}px)`;c.style.filter=`brightness(${1-.4*p})`}
else if(an=='fade'){c.style.opacity=1-p}
else if(an=='flip'){top.style.transformOrigin='0 50%';top.style.transform=`rotateY(${-pt*100}deg)`;top.style.boxShadow=`${8*pt}px 0 30px #0008`;und.style.filter=`brightness(${.55+.45*pt})`}}
async function beginTurn(dir,np,tgt,an){const st=$('#stage'),T={dir,np,tgt,an,cur:R.cur};T.top=dir>0?T.cur:tgt;T.under=dir>0?tgt:T.cur;
T.under.style.zIndex=1;T.top.style.zIndex=2;if(an=='cover'||an=='slide'){tgt.style.zIndex=2;T.cur.style.zIndex=1}if(an=='fade'){tgt.style.zIndex=1;T.cur.style.zIndex=2}
st.insertBefore(tgt,$('#foot'));
if(an=='curl'){T.flap=await pageEl(dir>0?R.pos:np);T.flap.style.transformOrigin='0 0';T.flap.style.zIndex='';
T.sw=document.createElement('div');T.sw.className='sw';T.sw.style.cssText=`width:${G.W}px;height:${G.H}px;z-index:3`;T.strip=document.createElement('div');T.strip.style.cssText=`position:absolute;left:0;top:0;width:100px;height:${3*G.H}px;transform-origin:0 0;background:linear-gradient(90deg,rgba(0,0,0,.55),rgba(0,0,0,.2) 35%,transparent)`;T.sw.append(T.strip);
T.fw=document.createElement('div');T.fw.className='fw';T.fw.style.cssText=`width:${G.W}px;height:${G.H}px;z-index:4`;const ff=document.createElement('div');ff.style.cssText='position:absolute;inset:0;filter:drop-shadow(-7px 3px 9px rgba(0,0,0,.45))';
T.fo=document.createElement('div');T.fo.style.cssText='position:absolute;inset:0;pointer-events:none';T.flap.append(T.fo);ff.append(T.flap);T.fw.append(ff);st.insertBefore(T.sw,$('#foot'));st.insertBefore(T.fw,$('#foot'));T.draw=(p,fy)=>frameCurl(T,p,fy)}
else T.draw=(p)=>frameOther(T,p);
R.turning=T;T.draw(0,G.H*.8);return T}
function endTurn(T,commit){for(const e of[T.sw,T.fw])e&&e.remove();const reset=e=>{e.style.cssText=`width:${G.W}px;height:${G.H}px`};
if(commit){reset(T.tgt);R.cur.remove();R.cur=T.tgt;R.pos=T.np;T.tgt.style.zIndex=1}else{T.tgt.remove();reset(T.cur);T.cur.style.zIndex=1}R.turning=null;if(commit){hideSel();updateUI();prefetch()}}
function settle(T,from,to,fy,dur){return new Promise(res=>{const t0=performance.now(),tick=now=>{const k=Math.min(1,(now-t0)/dur),e=1-Math.pow(1-k,3);T.draw(from+(to-from)*e,fy);k<1?requestAnimationFrame(tick):res()};requestAnimationFrame(tick)})}
async function turn(dir,fy){if(R.turning||S.md=='scroll'&&R.bk.kind!='pdf')return;const np=dir>0?await nextPos(R.pos):await prevPos(R.pos);if(!np){toast(dir>0?'You reached the end':'This is the first page');return}
const tgt=await pageEl(np),an=R.bk.kind=='pdf'&&S.an=='curl'?'curl':S.an;
if(an=='none'){R.turning={};R.pos=np;R.turning=null;setCur(tgt);hideSel();updateUI();prefetch();return}
const T=await beginTurn(dir,np,tgt,an);await settle(T,0,1,fy??G.H*.82,an=='curl'?560:300);endTurn(T,true)}
let G0=null;const hasSel=()=>{const s=getSelection();return s&&!s.isCollapsed&&s.toString().length>0};
function bindStage(){const st=$('#stage');
st.addEventListener('touchstart',e=>{if(e.touches.length>1||R.turning){G0=null;return}const t=e.touches[0];G0={x:t.clientX,y:t.clientY,t:Date.now(),drag:false,vx:0,lx:t.clientX,lt:Date.now()}},{passive:true});
st.addEventListener('touchmove',e=>{if(!G0||R.turning&&!G0.T)return;const t=e.touches[0],dx=t.clientX-G0.x,dy=t.clientY-G0.y,now=Date.now();
if(!G0.drag){if(S.md=='scroll'&&R.bk.kind!='pdf'||hasSel())return;if(Math.abs(dx)>12&&Math.abs(dx)>Math.abs(dy)*1.2){G0.drag=true;G0.dir=dx<0?1:-1;G0.ready=false;const d=G0.dir;
(async()=>{const np=d>0?await nextPos(R.pos):await prevPos(R.pos);if(!np){G0.none=true;return}const tgt=await pageEl(np);if(!G0||G0.dir!=d)return;const an=S.an=='none'?'slide':S.an;G0.T=await beginTurn(d,np,tgt,an);G0.ready=true;G0.p=0;G0.draw()})();G0.draw=()=>{const T=G0.T;if(!T)return;const W=G.W,p=G0.dir>0?(G0.x-G0.lx)/(W*.85):(G0.lx-G0.x)/(W*.85);G0.p=Math.max(0,Math.min(1,p));T.draw(G0.p,Math.max(20,Math.min(G.H-20,G0.ly)))}}else return}
if(G0.drag){e.preventDefault();const dt=now-G0.lt;if(dt>0)G0.vx=(t.clientX-G0.lx)/dt;G0.lx=t.clientX;G0.ly=t.clientY;G0.lt=now;if(G0.ready)G0.draw()}},{passive:false});
const end=async e=>{if(!G0)return;const g=G0;G0=null;const t=(e.changedTouches||[{clientX:g.lx,clientY:g.y}])[0];
if(g.drag){if(g.none){toast(g.dir>0?'You reached the end':'This is the first page');return}
for(let i=0;i<40&&!g.ready;i++)await sleep(25);const T=g.T;if(!T)return;const fwd=g.dir>0,v=g.vx*(fwd?-1:1),commit=g.p>.38||(v>.5&&g.p>.04);
await settle(T,g.p,commit?1:0,Math.max(20,Math.min(G.H-20,g.ly||G.H*.8)),commit?240+(1-g.p)*200:200);endTurn(T,commit);return}
if(e.type=='touchcancel'||R.turning)return;const dx=t.clientX-g.x,dy=t.clientY-g.y;if(Math.abs(dx)>14||Math.abs(dy)>14||Date.now()-g.t>450)return;
if(hasSel()){return}const a=document.elementFromPoint(t.clientX,t.clientY),lk=a&&a.closest('a[data-ih]'),mk=a&&a.closest('mark');
if(lk){followLink(lk.dataset.ih);return}if(mk){editHL(mk.dataset.id);return}
const x=t.clientX/G.W;if(S.md=='scroll'&&R.bk.kind!='pdf'){toggleUI();return}
if(S.zones&&x<.28)turn(-1,t.clientY);else if(S.zones&&x>.72)turn(1,t.clientY);else toggleUI()};
st.addEventListener('touchend',end);st.addEventListener('touchcancel',end);
st.addEventListener('click',e=>{if(e.detail&&!('ontouchstart' in window)){const x=e.clientX/G.W;if(x<.28)turn(-1,e.clientY);else if(x>.72)turn(1,e.clientY);else toggleUI()}});
document.addEventListener('selectionchange',()=>{clearTimeout(bindStage.t);bindStage.t=setTimeout(selUI,250)})}
async function followLink(h){const[p,f]=h.split('#'),ci=R.bk.spineIdx[p];if(ci!=null)jump({ci,fr:0,frag:f})}
/* ---- selection / highlights ---- */
let SEL=null;const hideSel=()=>{SEL=null;$('#seltb').className=''};
function selUI(){if(!R.b||!$('#reader.on')||!R.cur)return;const s=getSelection();if(!s||s.isCollapsed||!s.rangeCount){hideSel();return}const r=s.getRangeAt(0),root=R.cur.querySelector('.cols');
if(!root||!root.contains(r.commonAncestorContainer)){hideSel();return}const a=textOff(root,r.startContainer,r.startOffset),b=textOff(root,r.endContainer,r.endOffset);if(b<=a){hideSel();return}
SEL={ci:R.pos.ci,s:a,e:b,t:s.toString().trim().slice(0,300)};const rc=r.getBoundingClientRect(),tb=$('#seltb');tb.innerHTML=HCOL.map((c,i)=>`<button class="dot" data-hc="${i}" style="background:${c}"></button>`).join('')+`<button class="t" data-sa="note">${ic('pen','s')}</button><button class="t" data-sa="copy">${ic('copy','s')}</button><button class="t" data-sa="share">${ic('share','s')}</button>`;
tb.className='on';tb.style.left=Math.max(130,Math.min(innerWidth-130,rc.left+rc.width/2))+'px';tb.style.top=Math.max(70,rc.top-58)+'px'}
function addHL(c,note){if(!SEL)return;const h={id:'h'+Date.now().toString(36),ci:SEL.ci,s:SEL.s,e:SEL.e,c,t:SEL.t,note:note||'',d:Date.now()};R.b.hl.push(h);saveBook(R.b,1);getSelection().removeAllRanges();hideSel();refreshCur();return h}
async function refreshCur(){const el=await pageEl(R.pos);setCur(el)}
$('#seltb').addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;e.stopPropagation();
if(b.dataset.hc!=null)addHL(+b.dataset.hc);else if(b.dataset.sa=='copy'){try{await navigator.clipboard.writeText(SEL.t);toast('Copied')}catch(x){toast('Copy not available')}hideSel()}
else if(b.dataset.sa=='share'){const t=SEL.t+'\n— '+R.b.title;try{navigator.share?await navigator.share({text:t}):(await navigator.clipboard.writeText(t),toast('Quote copied'))}catch(x){}hideSel()}
else if(b.dataset.sa=='note'){const sv=SEL;const t=await askText('Add a note','Your note…','');if(t==null){return}SEL=sv;addHL(0,t)}});
function editHL(id){const h=R.b.hl.find(x=>x.id==id);if(!h)return;sheet(`<h3>Highlight</h3><div class="mut" style="margin-bottom:10px;font-style:italic">“${esc(h.t)}”</div>${h.note?`<div class="card" style="padding:10px;margin-bottom:10px">${esc(h.note)}</div>`:''}
<div style="display:flex;gap:12px;margin:10px 0">${HCOL.map((c,i)=>`<button data-hcol="${i}" style="width:36px;height:36px;border-radius:50%;background:${c};border:${h.c==i?'3px solid #fff':'2px solid #fff5'}"></button>`).join('')}</div>
<div style="display:flex;gap:10px;margin-top:8px"><button class="btn g" data-hnote>${ic('pen','s')} ${h.note?'Edit note':'Add note'}</button><button class="btn red" data-hdel>${ic('trash','s')} Delete</button></div>`,async e=>{const b=e.target.closest('button');if(!b)return;
if(b.dataset.hcol!=null){h.c=+b.dataset.hcol;saveBook(R.b,1);closeSheet();refreshCur()}else if('hdel' in b.dataset){R.b.hl=R.b.hl.filter(x=>x!==h);saveBook(R.b,1);closeSheet();refreshCur()}
else if('hnote' in b.dataset){closeSheet();const t=await askText('Note','Your note…',h.note);if(t!=null){h.note=t;saveBook(R.b,1);refreshCur()}}})}
/* ---- open / close ---- */
async function openBook(id){const b=books.find(x=>x.id==id);if(!b)return;R.b=b;$('#reader').classList.add('on');busy('Opening…');R.ui=false;$('#rtop').classList.add('off');$('#rbot').classList.add('off');
try{const buf=await bookBytes(b);if(!buf)throw new Error('File not found. Re-add the book or rescan your folder.');const nm=b.id.split('|')[0];
R.bk=b.fmt=='epub'?await openEpub(buf):b.fmt=='pdf'?await openPdf(buf):flowFromText(buf,b.fmt,nm);
R.pg={};R.hc.clear();R.pdfc.clear();R.mp=0;R.mw=0;R.cum=[0];R.bk.wts.forEach(w=>R.cum.push(R.cum[R.cum.length-1]+w));R.tot=R.cum[R.cum.length-1]||1;
await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));calcGeom();applyVars();const st=$('#stage');if(!meas.parentNode)st.append(meas);
const p=b.pos||{ci:0,fr:0};const ci=Math.min(R.bk.n-1,p.ci),n=await pagesOf(ci);R.pos={ci,pi:Math.min(n-1,Math.floor((p.fr||0)*n))};
$('#rcov').src=b.cover;$('#rtit').textContent=b.title;$('#raut').textContent=b.author||'';b.opened=Date.now();const dy=new Date().toDateString();if(!(dy in S.days)){S.days[dy]=0;save()}
await showCurrent();busy('')}catch(e){console.error(e);busy('');closeReader(true);toast('Could not open this book: '+(e.message||e))}}
async function closeReader(quiet){if(R.b&&R.pos&&!quiet)saveBook(R.b,1);try{R.bk&&R.bk.close()}catch(e){}R.bk=null;R.turning=null;const st=$('#stage');[...st.children].forEach(c=>{if(c.classList.contains('page')||c.classList.contains('sw')||c.classList.contains('fw'))c.remove()});R.cur=null;
$('#reader').classList.remove('on');hideSel();closeSheet();R.b=null;renderAll()}
function toggleUI(force){R.ui=force??!R.ui;$('#rtop').classList.toggle('off',!R.ui);$('#rbot').classList.toggle('off',!R.ui);if(R.ui)updateUI()}
setInterval(()=>{if(R.b&&$('#reader.on')&&document.visibilityState=='visible'){const d=new Date().toDateString();S.rs+=5;S.days[d]=(S.days[d]||0)+5;const k=Object.keys(S.days);if(k.length>400)delete S.days[k[0]];save()}},5000);
let rzT;addEventListener('resize',()=>{clearTimeout(rzT);rzT=setTimeout(()=>{if(R.bk&&!R.turning&&$('#reader.on'))relayout()},300)});
async function relayout(){if(!R.bk||!R.pos)return;const ci=R.pos.ci,fr=curFr();R.pg={};R.mp=0;R.mw=0;R.pdfc.clear();calcGeom();applyVars();const n=await pagesOf(ci);R.pos={ci,pi:Math.min(n-1,Math.floor(fr*n))};await showCurrent()}
/* ---- reader chrome ---- */
$('#rback').onclick=()=>closeReader();
$('#rsl').oninput=e=>{const v=+e.target.value/1000*R.tot;let ci=0;while(ci<R.bk.n-1&&R.cum[ci+1]<=v)ci++;clearTimeout($('#rsl').t);$('#rsl').t=setTimeout(()=>jump({ci,fr:Math.max(0,(v-R.cum[ci])/R.bk.wts[ci])}),120)};
$('#rbm').onclick=()=>{const fr=curFr(),ix=R.b.marks.findIndex(m=>m.ci==R.pos.ci&&Math.abs(m.fr-fr)<.5/(R.pg[R.pos.ci]||1));if(ix>=0){R.b.marks.splice(ix,1);toast('Bookmark removed')}else{R.b.marks.push({ci:R.pos.ci,fr,t:chTitle(R.pos.ci),p:Math.round(overall(R.pos)*100),d:Date.now()});toast('Bookmark added')}saveBook(R.b,1);updateUI()};
$('#rtoc').onclick=()=>contents('toc');$('#rnotes').onclick=()=>contents('notes');$('#rsrch').onclick=bookSearch;$('#rset').onclick=()=>readerSettings('disp');$('#rmore').onclick=()=>contents('marks');
function contents(tab){const b=R.b,tabs=[['toc','Contents'],['marks','Bookmarks'],['notes','Notes']];
const body=t=>{if(t=='toc')return R.bk.toc.length?R.bk.toc.map((e,i)=>`<div class="hit" data-ci="${e.ci}" data-fr="0" data-fg="${esc(e.frag)}" style="padding-left:${4+e.d*16}px${e.ci==R.pos.ci?';color:var(--ac)':''}">${esc(e.label)}</div>`).join(''):'<div class="empty">No table of contents in this book.</div>';
if(t=='marks')return b.marks.length?[...b.marks].sort((x,y)=>x.ci-y.ci||x.fr-y.fr).map(m=>`<div class="hit" data-ci="${m.ci}" data-fr="${m.fr}" data-fg=""><small>${m.p}% · ${new Date(m.d).toLocaleDateString()}</small>${esc(m.t)}</div>`).join(''):'<div class="empty">No bookmarks yet. Tap the bookmark icon on a page.</div>';
return b.hl.length?[...b.hl].sort((x,y)=>x.ci-y.ci||x.s-y.s).map(h=>`<div class="hit" data-ci="${h.ci}" data-fr="${h.s/Math.max(1,(R.bk.wts[h.ci]||1))}" data-hid="${h.id}"><small style="color:${HCOL[h.c]}">● ${esc(chTitle(h.ci))}</small>“${esc(h.t)}”${h.note?`<div class="mut" style="margin-top:3px">✎ ${esc(h.note)}</div>`:''}</div>`).join(''):'<div class="empty">Select text in a page to highlight it or add a note.</div>'};
const draw=t=>{$('#sheet').innerHTML=`<i class="grab"></i><div class="tabsr">${tabs.map(([k,n])=>`<button class="pill sm${k==t?' on':''}" data-t="${k}">${n}</button>`).join('')}</div>${body(t)}`};
sheet('',async e=>{const t=e.target.closest('[data-t]');if(t){draw(t.dataset.t);return}const h=e.target.closest('.hit[data-ci]');if(h){closeSheet();toggleUI(false);let fr=+h.dataset.fr;if(h.dataset.hid){const hl=b.hl.find(x=>x.id==h.dataset.hid);fr=0;await pagesOf(hl.ci);const hh=await htmlOf(hl.ci);const tl=hh.replace(/<[^>]*>/g,'').length||1;fr=Math.min(.999,hl.s/tl)}jump({ci:+h.dataset.ci,fr,frag:h.dataset.fg||''})}});draw(tab)}
function bookSearch(){sheet(`<h3>Search in book</h3><input class="inp" id="bq" type="search" placeholder="Type and press Enter" enterkeyhint="search"><div id="bres"></div>`,e=>{const h=e.target.closest('.hit');if(h){closeSheet();toggleUI(false);jump({ci:+h.dataset.ci,fr:+h.dataset.fr})}});
$('#bq').addEventListener('keydown',async e=>{if(e.key!='Enter')return;const q=norm($('#bq').value.trim());if(q.length<2)return;const out=$('#bres');out.innerHTML='<div class="empty">Searching…</div>';let n=0,html='';
for(let ci=0;ci<R.bk.n&&n<80;ci++){if(R.bk.kind=='pdf'){const pg=await R.bk.doc.getPage(ci+1),tc=await pg.getTextContent(),tx=tc.items.map(i=>i.str).join(' '),nt=norm(tx);let i=nt.indexOf(q);if(i>=0){n++;html+=`<div class="hit" data-ci="${ci}" data-fr="0"><small>Page ${ci+1}</small>${esc(tx.slice(Math.max(0,i-40),i+80))}</div>`}continue}
const t=(await htmlOf(ci)).replace(/<[^>]*>/g,' ').replace(/&nbsp;/g,' ').replace(/\s+/g,' '),nt=norm(t);let i=-1,k=0;while((i=nt.indexOf(q,i+1))>=0&&k<4&&n<80){k++;n++;html+=`<div class="hit" data-ci="${ci}" data-fr="${i/Math.max(1,t.length)}"><small>${esc(chTitle(ci))}</small>${esc(t.slice(Math.max(0,i-40),i)).replace(/^\S*\s/,'')}<mark>${esc(t.slice(i,i+q.length))}</mark>${esc(t.slice(i+q.length,i+q.length+70))}</div>`}
if(ci%6==0){out.innerHTML=`<div class="empty">Searching… ${Math.round(ci/R.bk.n*100)}%</div>`;await sleep(0)}}
out.innerHTML=html||'<div class="empty">No results.</div>'});setTimeout(()=>$('#bq').focus(),300)}
function readerSettings(tab){const seg=(k,a)=>`<div class="opt" style="grid-template-columns:repeat(${a.length},1fr)">${a.map(([v,n])=>`<button data-s="${k}:${v}" class="${S[k]==v?'on':''}">${n}</button>`).join('')}</div>`;
const tabs=[['disp','Display'],['theme','Theme'],['lay','Layout'],['more','More']];
const body=t=>{if(t=='disp')return`<div class="lbl">Font</div><div class="opt" style="grid-template-columns:repeat(3,1fr)">${Object.entries(FONTS).map(([k,v])=>`<button data-s="ff:${k}" class="${S.ff==k?'on':''}" style="font-family:${v[1]}">${v[0]}</button>`).join('')}</div>
<div class="row"><span>Text size</span><div class="stp"><button data-st="fs:-1">A−</button><b>${S.fs}</b><button data-st="fs:1">A+</button></div></div>
<div class="lbl">Line spacing</div>${seg('lh',[[1.35,'Tight'],[1.6,'Normal'],[1.9,'Loose']])}<div class="lbl">Margins</div>${seg('mg',[[0,'Narrow'],[1,'Medium'],[2,'Wide']])}`;
if(t=='theme')return`<div class="thm">${Object.entries(RT).map(([k,v])=>{const c=k=='custom'?{bg:S.cbg,fg:S.cfg}:v;return`<button data-s="rt:${k}" class="${S.rt==k?'on':''}" style="background:${c.bg};color:${c.fg}">Aa<small style="color:inherit;font-size:11px">${v.n}</small></button>`}).join('')}</div>
${S.rt=='custom'?`<div class="row"><span>Background</span><input type="color" id="cbg" value="${S.cbg}"></div><div class="row"><span>Text</span><input type="color" id="cfg" value="${S.cfg}"></div>`:''}
<div class="row"><span>Brightness dim</span><input type="range" id="dimr" min="0" max="70" value="${S.dim}" style="width:50%"></div>`;
if(t=='lay')return`<div class="lbl">Page turn animation</div><div class="opt">${ANIMS.map(([k,n])=>`<button data-s="an:${k}" class="${S.an==k?'on':''}">${n}</button>`).join('')}</div><div class="lbl">Reading mode</div>${seg('md',[['paginated','Pages'],['scroll','Scroll']])}
<div class="row"><span>Justify text</span><div class="tg ${S.just?'on':''}" data-tg="just"></div></div>`;
return`<div class="row"><span>Tap screen edges to turn pages</span><div class="tg ${S.zones?'on':''}" data-tg="zones"></div></div><div class="row"><span>Reset reading settings</span><button class="btn g sm" data-reset>Reset</button></div>`};
const draw=t=>{$('#sheet').innerHTML=`<i class="grab"></i><div class="tabsr">${tabs.map(([k,n])=>`<button class="pill sm${k==t?' on':''}" data-t="${k}">${n}</button>`).join('')}</div>${body(t)}`;R.tab=t;
const cb=$('#cbg');if(cb){cb.oninput=()=>{S.cbg=cb.value;applyVars()};cb.onchange=()=>{save();relayout()}}const cf=$('#cfg');if(cf){cf.oninput=()=>{S.cfg=cf.value;applyVars()};cf.onchange=()=>{save();relayout()}}const d=$('#dimr');if(d)d.oninput=()=>{S.dim=+d.value;save();applyVars()}};
const RL=['ff','fs','lh','mg','just','rt','md'];
const chg=async(k,v)=>{S[k]=v;save();applyVars();if(RL.includes(k))await relayout();if(k=='md'){R.turning=null;await showCurrent()}draw(R.tab)};
sheet('',async e=>{const t=e.target.closest('[data-t]');if(t){draw(t.dataset.t);return}const s=e.target.closest('[data-s]');if(s){const[k,v]=s.dataset.s.split(':');await chg(k,isNaN(v)?v:+v);return}
const st=e.target.closest('[data-st]');if(st){const[k,d]=st.dataset.st.split(':');await chg(k,Math.max(12,Math.min(34,S[k]+ +d)));return}const tg=e.target.closest('[data-tg]');if(tg){await chg(tg.dataset.tg,S[tg.dataset.tg]?0:1);return}
if(e.target.closest('[data-reset]')){Object.assign(S,{ff:'lit',fs:19,lh:1.6,mg:1,just:1,rt:'night',dim:0,md:'paginated',an:'curl',zones:1});save();await relayout();draw(R.tab)}},true);draw(tab)}

$('#rq').onclick=async()=>{S.rt=isDark(rtheme().bg)?'paper':'night';save();applyVars();await relayout()};
