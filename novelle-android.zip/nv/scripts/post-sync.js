// Runs automatically after `npx cap sync` (Capacitor "capacitor:sync:after" hook).
// Copies Novelle's native folder plugin + launcher icons into the generated Android project.
const fs = require('fs'), path = require('path');
const root = process.env.CAPACITOR_ROOT_DIR || process.cwd();
const A = path.join(root, 'android');
const log = m => console.log('[novelle] ' + m);
function copyDir(s, d) {
  fs.mkdirSync(d, { recursive: true });
  for (const e of fs.readdirSync(s, { withFileTypes: true })) {
    const a = path.join(s, e.name), b = path.join(d, e.name);
    e.isDirectory() ? copyDir(a, b) : fs.copyFileSync(a, b);
  }
}
try {
  if (!fs.existsSync(A)) { log('no android folder yet, skipping'); process.exit(0); }
  const jd = path.join(A, 'app/src/main/java/com/novelle/reader');
  fs.mkdirSync(jd, { recursive: true });
  for (const f of ['NovelleFolderPlugin.java', 'NovelleUpdatePlugin.java', 'MainActivity.java'])
    fs.copyFileSync(path.join(root, 'native', f), path.join(jd, f));
  log('native folder plugin installed');
  const res = path.join(A, 'app/src/main/res');
  // remove icon variants that would clash with our PNGs
  if (fs.existsSync(res)) for (const d of fs.readdirSync(res)) {
    if (!d.startsWith('mipmap')) continue;
    for (const f of fs.readdirSync(path.join(res, d)))
      if (/^ic_launcher.*\.(webp|xml)$/.test(f) && d !== 'mipmap-anydpi-v26') fs.unlinkSync(path.join(res, d, f));
  }
  copyDir(path.join(root, 'native/res'), res);
  log('launcher icons installed');

  // ---- permission + file provider so Novelle can install its own updates ----
  const mf = path.join(A, 'app/src/main/AndroidManifest.xml');
  let x = fs.readFileSync(mf, 'utf8'), changed = false;
  if (!x.includes('REQUEST_INSTALL_PACKAGES')) {
    x = x.replace('</manifest>', '    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />\n</manifest>'); changed = true;
  }
  if (!x.includes('androidx.core.content.FileProvider')) {
    x = x.replace('</application>', '    <provider android:name="androidx.core.content.FileProvider" android:authorities="${applicationId}.fileprovider" android:exported="false" android:grantUriPermissions="true"><meta-data android:name="android.support.FILE_PROVIDER_PATHS" android:resource="@xml/file_paths" /></provider>\n    </application>'); changed = true;
    const fp = path.join(res, 'xml/file_paths.xml');
    if (!fs.existsSync(fp)) { fs.mkdirSync(path.dirname(fp), { recursive: true }); fs.writeFileSync(fp, '<?xml version="1.0" encoding="utf-8"?>\n<paths xmlns:android="http://schemas.android.com/apk/res/android">\n    <cache-path name="nv_cache" path="." />\n    <external-path name="nv_ext" path="." />\n</paths>\n'); }
  }
  if (changed) fs.writeFileSync(mf, x);
  log('update permission ready');
  // ---- stable signing key + build number (only when the workflow provides them) ----
  const gf = path.join(A, 'app/build.gradle');
  let g = fs.readFileSync(gf, 'utf8');
  if (!g.includes('novelle-signing')) {
    g += `
// novelle-signing (added by scripts/post-sync.js)
if (System.getenv('NV_KS')) {
  android {
    signingConfigs {
      novelle {
        storeFile file(System.getenv('NV_KS'))
        storePassword System.getenv('NV_PASS')
        keyAlias 'novelle'
        keyPassword System.getenv('NV_PASS')
      }
    }
    defaultConfig {
      versionCode Integer.parseInt(System.getenv('NV_BUILD') ?: '1')
      versionName '2.' + (System.getenv('NV_BUILD') ?: '0')
    }
    buildTypes {
      debug { signingConfig signingConfigs.novelle }
      release { signingConfig signingConfigs.novelle }
    }
  }
}
`;
    fs.writeFileSync(gf, g);
  }
  log('signing hook ready');
} catch (e) { console.error('[novelle] post-sync warning:', e); }
