# Novelle
1. Create a GitHub repo, upload everything in this folder, push to `main`.
2. Open the **Actions** tab, wait for "Build Novelle APK" to finish.
3. Download the **Novelle-APK** artifact, unzip, install `app-debug.apk` (allow unknown sources).
App source: `src/index.html`. Icon source: `assets/icon-only.png`.
