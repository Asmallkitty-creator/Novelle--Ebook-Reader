**What's new**
- Realistic page curl: the page now rolls over like paper, with soft shadows and a see-through back. No more flat cards or stray white boxes.
- Smarter sorting: books without tags are sorted into Fiction or Non-Fiction by reading their description and opening pages. Existing books are re-checked quietly in the background.
- Discover now has two modes: **My Library** and **Find New** (recommendations of books you don't own yet, with store links and a wishlist).
- The scanning pop-up can be minimised to a small circle, dragged anywhere, and hides itself while you read.
- Home screen covers are now a uniform size.
- Novelle can update itself: About → Check for updates.
