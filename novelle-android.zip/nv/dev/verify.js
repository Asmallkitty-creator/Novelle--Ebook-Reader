/* ================= VERIFICATION ENGINE ================= */
const UA='Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36';
const isNative=()=>{try{return!!(window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform())}catch(e){return false}};
const net={async get(url,o={}){const ms=o.ms||9000,H=Object.assign({'Accept':'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8','Accept-Language':'en-US,en;q=0.9,ro;q=0.8'},o.headers||{});
const N=isNative()&&Capacitor.Plugins&&Capacitor.Plugins.CapacitorHttp;
if(N){const r=await N.request({url,method:'GET',headers:Object.assign({'User-Agent':UA},H),responseType:'text',connectTimeout:ms,readTimeout:ms});return{status:r.status,text:typeof r.data=='string'?r.data:JSON.stringify(r.data||''),url:r.url||url}}
const c=new AbortController(),t=setTimeout(()=>c.abort(),ms);try{const r=await fetch(url,{headers:H,signal:c.signal,redirect:'follow'});return{status:r.status,text:await r.text(),url:r.url||url}}finally{clearTimeout(t)}}};
const enc=encodeURIComponent;
const STOP=new Set('the a an of and in on to for by with de la si un o cu pe din care sau al ale lui se ca mai ce nu cel cea'.split(' '));
const toks=s=>norm(s).replace(/[^a-z0-9]+/g,' ').split(' ').filter(w=>w&&!STOP.has(w)&&(w.length>1||/\d/.test(w)));
const ovl=(a,b)=>{if(!a.length||!b.length)return 0;const B=new Set(b);return a.filter(x=>B.has(x)).length/a.length};
const cleanTitle=t=>String(t||'').replace(/[\(\[].*?[\)\]]/g,' ').replace(/\s[-–—]\s.*$/,'').replace(/\.(epub|pdf|txt|html?)$/i,'').replace(/_+/g,' ').replace(/\s+/g,' ').trim();
const authLast=a=>{const s=String(a||'').split(/;|&| and | și /i)[0].trim();if(!s)return'';if(s.includes(','))return s.split(',')[0].trim();const w=s.split(/\s+/);return w[w.length-1]};
const looksRo=b=>/^ro/i.test(b.lang||'')||/[ăâîșțşţ]/i.test(b.title+' '+b.author)||/\b(și|din|pentru|într?-o?|despre)\b/i.test(b.title);
const NOISE=/^(home|acasa|carti|carte|books?|ebooks?|e-?books?|toate|all|all categories|categorii|categories|categorie|kindle store|kindle|audiobooks?|magazin|shop|store|online|cumpara|buy|pagina principala|prima pagina|librarie|librarie online|bookstore|romania|index|produse|products|stock|nou|new|promotii|oferte|cadouri|gifts|catalog|biblioteca|library|wishlist|search|cauta|cautare|results|rezultate|goodreads|amazon|ebooks & audiobooks|literatura & ficțiune)$/i;
const TAGNOISE=/^fiction[, ]+(general|literary|classics)|general fiction|accessible book|protected daisy|in library|large type|reading level|nyt:|open library|overdrive|lending library|internet archive|juvenile literature|specimens|study guide|study and teaching|new york times|bestseller|^fiction$|^general$|^unknown$|^books?$|^ebooks?$|^literature$|translations?|^english$|^romanian$|history and criticism|criticism and interpretation|^cărți$|^carti$|^new$|^sale$|^promo|^free|^audio|^paperback|^hardcover|^kindle|^isbn|^[0-9\W]+$/i;
function cleanCats(a,title){const tt=toks(title),seen=new Set(),out=[];for(let s of a){s=String(s||'').replace(/\s+/g,' ').trim();if(s.length<2||s.length>60)continue;const k=norm(s);if(NOISE.test(k)||seen.has(k))continue;if(tt.length&&ovl(tt,toks(s))>=.8&&toks(s).length>=Math.max(2,tt.length-1))continue;seen.add(k);out.push(s)}return out}
const TC=s=>s.replace(/\w\S*/g,w=>w[0].toUpperCase()+w.slice(1).toLowerCase());
function cleanTags(a){const seen=new Set(),out=[];for(let s of a){s=String(s||'').replace(/\s+/g,' ').replace(/^[#\-–\s]+|[\s.\-–,]+$/g,'').trim();if(s.length<3||s.length>32||s.split(' ').length>4||TAGNOISE.test(s)||NOISE.test(norm(s)))continue;const k=norm(s);if(seen.has(k))continue;seen.add(k);out.push(/[A-Z]/.test(s.slice(1))?s:TC(s))}return out}
/* ---------- generic page extractor ---------- */
function pageData(doc,base,x){const o={title:'',author:'',cats:[],tags:[],desc:''};
const A=(k,v)=>{(Array.isArray(v)?v:[v]).forEach(s=>{s=String((s&&s.name)||s||'').replace(/\s+/g,' ').trim();if(s&&s.length<90)o[k].push(s)})};
const ld=n=>{if(!n)return;if(Array.isArray(n)){n.forEach(ld);return}if(typeof n!='object')return;if(n['@graph'])ld(n['@graph']);const t=[].concat(n['@type']||[]).join(' ');
if(/Book|Product|CreativeWork|Audiobook|Publication|Periodical/i.test(t)){if(!o.title&&n.name)o.title=String(n.name);if(!o.author&&n.author)o.author=[].concat(n.author).map(a=>(a&&a.name)||a).join(', ');if(n.genre)A('cats',n.genre);if(n.category)A('cats',[].concat(n.category).flatMap(c=>String((c&&c.name)||c).split(/\s*[>\/|»›]\s*/)));if(n.keywords)A('tags',typeof n.keywords=='string'?n.keywords.split(/[,;|]/):n.keywords);if(n.description&&!o.desc)o.desc=String(n.description).slice(0,1500)}
if(/BreadcrumbList/i.test(t))A('cats',(n.itemListElement||[]).map(i=>(i.item&&i.item.name)||i.name));
if(n.breadcrumb)ld(n.breadcrumb)};
doc.querySelectorAll('script[type="application/ld+json"]').forEach(s=>{try{ld(JSON.parse(s.textContent.trim()))}catch(e){}});
const m=(sel,at='content')=>[...doc.querySelectorAll(sel)].map(e=>e.getAttribute(at)).filter(Boolean);
A('tags',m('meta[property="book:tag"]'));A('cats',m('meta[property="product:category"],meta[property="article:section"]'));
const kw=m('meta[name=keywords]')[0];if(kw){const k=kw.split(/[,;]/).map(s=>s.trim()).filter(Boolean);if(k.length<=14)A('tags',k)}
if(!o.desc)o.desc=(m('meta[property="og:description"]')[0]||m('meta[name=description]')[0]||'').slice(0,1500);
if(!o.title)o.title=(m('meta[property="og:title"]')[0]||(doc.querySelector('h1')||{}).textContent||doc.title||'').replace(/\s+/g,' ').trim();
A('cats',[...doc.querySelectorAll('[itemtype*="BreadcrumbList"] [itemprop=name],nav[aria-label*=readcrumb] a,nav[aria-label*=readcrumb] li,.breadcrumb a,.breadcrumbs a,.breadcrumb li,.breadcrumbs li,[class*=readcrumb] a,[id*=readcrumb] a')].map(e=>e.textContent));
if(x)try{x(doc,o,A)}catch(e){}
o.cats=cleanCats(o.cats,o.title);o.tags=cleanTags(o.tags);return o}
const TX=e=>{const w=e.ownerDocument.createTreeWalker(e,NodeFilter.SHOW_TEXT);let s='',n;while(n=w.nextNode())s+=' '+n.nodeValue;return s.replace(/\s+/g,' ').trim()};
function pickLink(doc,base,rx,tt,minOv=.6){let best=null,bs=0,host;try{host=new URL(base).host}catch(e){return null}
for(const a of doc.querySelectorAll('a[href]')){const h=a.getAttribute('href')||'';if(!h||h[0]=='#'||/^(javascript|mailto|tel):/i.test(h))continue;let u;try{u=new URL(h,base)}catch(e){continue}
if(!/^https?:$/.test(u.protocol)||u.host.replace(/^www\./,'')!=host.replace(/^www\./,''))continue;if(/(^|\/)(login|logout|cart|cos|checkout|account|cont|wishlist|signin|register|search|cauta|cautare)(\/|$|\.)/i.test(u.pathname))continue;
let el=a,txt=TX(a)+' '+(a.getAttribute('title')||'')+' '+(a.getAttribute('aria-label')||'')+' '+[...a.querySelectorAll('img')].map(i=>i.alt).join(' ');
for(let k=0;k<3&&toks(txt).length<=toks(tt.join(' ')).length+1&&el.parentElement;k++){el=el.parentElement;const t2=TX(el);if(t2.length<500)txt=t2+' '+txt}
const ov=ovl(tt,toks(txt));if(ov<minOv)continue;const sc=ov+(rx&&rx.test(u.pathname+u.search)?.35:0)-(txt.length>300?.1:0);if(sc>bs){bs=sc;best=u.href}}
return best}
const fin=(pd,url)=>({url,title:pd.title,cats:pd.cats,tags:pd.tags,desc:pd.desc});
const BLK=s=>s==403||s==429||s==503||s==401;
function STORE(id,name,lang,host,urls,rx,def,x){return{id,name,lang,host,kind:'store',def,async run(q){let last=null;
for(const u of urls(q)){let r;try{r=await net.get(u)}catch(e){last=e;continue}
if(BLK(r.status))throw new Error('blocked');if(r.status>=400)continue;
const doc=new DOMParser().parseFromString(r.text,'text/html');
const p0=pageData(doc,r.url,x);if(p0.title&&ovl(q.tt,toks(p0.title))>=.75&&(p0.cats.length||p0.tags.length)&&!/search|cauta|results|rezultat/i.test(r.url))return fin(p0,r.url);
const link=pickLink(doc,r.url,rx,q.tt);if(!link)continue;
const r2=await net.get(link);if(BLK(r2.status))throw new Error('blocked');if(r2.status>=400)continue;
const d2=new DOMParser().parseFromString(r2.text,'text/html'),pd=pageData(d2,r2.url||link,x);
if(pd.title&&ovl(q.tt,toks(pd.title))<.5)return null;if(!pd.cats.length&&!pd.tags.length)return null;return fin(pd,link)}
if(last)throw last;return null}}}
const jget=async u=>{const r=await net.get(u);if(r.status>=400)throw new Error('http '+r.status);return JSON.parse(r.text)};
const authOk=(q,names)=>!q.a||!names||!names.length||names.some(n=>ovl(toks(q.a),toks(String(n)))>=.5||toks(String(n)).includes(norm(q.a)));
const API=[
{id:'ol',name:'Open Library',lang:'en',host:'openlibrary.org',kind:'lib',def:1,async run(q){const j=await jget(`https://openlibrary.org/search.json?title=${enc(q.t)}${q.a?'&author='+enc(q.a):''}&limit=6&fields=title,author_name,subject,key`);
const d=(j.docs||[]).filter(d=>ovl(q.tt,toks(d.title||''))>=.7&&authOk(q,d.author_name)).sort((a,b)=>(b.subject||[]).length-(a.subject||[]).length)[0];if(!d||!(d.subject||[]).length)return null;const s=(d.subject||[]).slice(0,50);return{url:'https://openlibrary.org'+d.key,title:d.title,cats:s,tags:cleanTags(s),desc:''}}},
{id:'gb',name:'Google Books',lang:'en',host:'books.google.com',kind:'lib',def:1,async run(q){const j=await jget(`https://www.googleapis.com/books/v1/volumes?q=intitle:${enc(q.t)}${q.a?'+inauthor:'+enc(q.a):''}&maxResults=6&printType=books`);
const it=(j.items||[]).find(i=>{const v=i.volumeInfo||{};return ovl(q.tt,toks(v.title||''))>=.7&&authOk(q,v.authors)});if(!it)return null;const v=it.volumeInfo;const cats=(v.categories||[]).flatMap(c=>String(c).split(/\s*\/\s*/));
if(!cats.length&&!v.description)return null;return{url:v.infoLink||'https://books.google.com/books?id='+it.id,title:v.title,cats,tags:cleanTags(cats),desc:String(v.description||'').slice(0,1500)}}},
{id:'loc',name:'Library of Congress',lang:'en',host:'loc.gov',kind:'lib',def:1,async run(q){const j=await jget(`https://www.loc.gov/books/?q=${enc(q.t+' '+q.a)}&fo=json&c=6`);
const d=(j.results||[]).find(r=>ovl(q.tt,toks(String(r.title||'')))>=.7&&(r.subject||[]).length);if(!d)return null;const s=[].concat(d.subject).slice(0,40);return{url:d.url||d.id||'https://www.loc.gov/books/',title:String(d.title),cats:s,tags:cleanTags(s),desc:String([].concat(d.description||'')[0]||'').slice(0,800)}}},
{id:'ia',name:'Internet Archive',lang:'en',host:'archive.org',kind:'lib',def:1,async run(q){const j=await jget(`https://archive.org/advancedsearch.php?q=${enc('title:('+q.t+')'+(q.a?' AND creator:('+q.a+')':''))}&fl%5B%5D=title&fl%5B%5D=subject&fl%5B%5D=creator&fl%5B%5D=identifier&rows=8&output=json`);
const d=((j.response||{}).docs||[]).find(r=>ovl(q.tt,toks(String(r.title||'')))>=.7&&r.subject);if(!d)return null;const s=[].concat(d.subject).flatMap(x=>String(x).split(/;/)).slice(0,40);return{url:'https://archive.org/details/'+d.identifier,title:String(d.title),cats:s,tags:cleanTags(s),desc:''}}},
{id:'wd',name:'Wikidata',lang:'en',host:'wikidata.org',kind:'lib',def:1,async run(q){const s=await jget(`https://www.wikidata.org/w/api.php?action=wbsearchentities&search=${enc(q.t)}&language=en&type=item&limit=6&format=json&origin=*`);
const e=(s.search||[]).find(x=>ovl(q.tt,toks(x.label||''))>=.8&&/novel|book|literary|written work|story|poem|play|series|comics|manga|collection/i.test(x.description||''));if(!e)return null;
const c=await jget(`https://www.wikidata.org/w/api.php?action=wbgetentities&ids=${e.id}&props=claims&format=json&origin=*`);const g=(((c.entities||{})[e.id]||{}).claims||{}).P136||[];const ids=g.map(x=>x.mainsnak&&x.mainsnak.datavalue&&x.mainsnak.datavalue.value&&x.mainsnak.datavalue.value.id).filter(Boolean);if(!ids.length)return null;
const l=await jget(`https://www.wikidata.org/w/api.php?action=wbgetentities&ids=${ids.join('|')}&props=labels&languages=en&format=json&origin=*`);const lab=ids.map(i=>((((l.entities||{})[i]||{}).labels||{}).en||{}).value).filter(Boolean);return lab.length?{url:'https://www.wikidata.org/wiki/'+e.id,title:e.label,cats:lab,tags:cleanTags(lab),desc:e.description||''}:null}}];
const E=s=>q=>[s.replace('{q}',enc(q.q)).replace('{t}',enc(q.t))];
const SRC=[...API,
STORE('goodreads','Goodreads','en','goodreads.com',E('https://www.goodreads.com/search?q={q}'),/\/book\/show\//,1,(d,o,A)=>{A('cats',[...d.querySelectorAll('[data-testid="genresList"] a,.BookPageMetadataSection__genreButton a,a.bookPageGenreLink,a[href*="/genres/"]')].slice(0,10).map(e=>e.textContent))}),
STORE('lt','LibraryThing','en','librarything.com',E('https://www.librarything.com/search.php?search={q}&searchtype=newwork_titles'),/\/work\//,1,(d,o,A)=>{A('tags',[...d.querySelectorAll('a[href*="/tag/"]')].slice(0,20).map(e=>e.textContent))}),
STORE('bn','Barnes & Noble','en','barnesandnoble.com',E('https://www.barnesandnoble.com/s/{q}'),/\/w\//,1),
STORE('waterstones','Waterstones','en','waterstones.com',E('https://www.waterstones.com/books/search/term/{q}'),/\/book\//,1),
STORE('bookshop','Bookshop.org','en','bookshop.org',E('https://bookshop.org/search?keywords={q}'),/\/p\/books\//,1),
STORE('blackwells','Blackwell’s','en','blackwells.co.uk',E('https://blackwells.co.uk/bookshop/search?keyword={q}'),/\/bookshop\/product\//,1),
STORE('kobo','Kobo','en','kobo.com',E('https://www.kobo.com/us/en/search?query={q}'),/\/ebook\//,0),
STORE('amazon','Amazon','en','amazon.com',E('https://www.amazon.com/s?k={q}&i=stripbooks'),/\/dp\//,0,(d,o,A)=>{A('cats',[...d.querySelectorAll('#wayfinding-breadcrumbs_feature_div a')].map(e=>e.textContent))}),
STORE('storygraph','The StoryGraph','en','thestorygraph.com',E('https://app.thestorygraph.com/browse?search_term={q}'),/\/books\//,0,(d,o,A)=>{A('tags',[...d.querySelectorAll('[class*=tag-section] span,.book-page-tag-section span')].slice(0,25).map(e=>e.textContent))}),
STORE('carturesti','Cărturești','ro','carturesti.ro',E('https://carturesti.ro/product/search/{q}'),/\/carte\//,1),
STORE('emag','eMAG','ro','emag.ro',E('https://www.emag.ro/search/{q}'),/\/pd\//,1),
STORE('elefant','Elefant','ro','elefant.ro',E('https://www.elefant.ro/search?SearchTerm={q}'),/\.html|\/carti\//,1),
STORE('libris','Libris','ro','libris.ro',q=>[`https://www.libris.ro/?s=${enc(q.q)}`,`https://www.libris.ro/cautare?q=${enc(q.q)}`],/\.html|libris\.ro\//,1),
STORE('bookzone','Bookzone','ro','bookzone.ro',E('https://www.bookzone.ro/cautare?term={q}'),/\/carte\/|\/produs\//,1),
STORE('librarienet','Librarie.net','ro','librarie.net',E('https://www.librarie.net/cautare-rezultate.php?t={q}'),/\/carte\/|\/produs\//,1),
STORE('humanitas','Humanitas','ro','humanitas.ro',q=>[`https://www.humanitas.ro/cauta?q=${enc(q.q)}`,`https://www.humanitas.ro/?s=${enc(q.q)}`],/\/carte\//,1),
STORE('polirom','Polirom','ro','polirom.ro',q=>[`https://www.polirom.ro/cautare?q=${enc(q.q)}`,`https://www.polirom.ro/?s=${enc(q.q)}`],/\/carte\//,1),
STORE('litera','Litera','ro','litera.ro',E('https://litera.ro/?s={q}&post_type=product'),/\/product\//,1),
STORE('okian','Okian','ro','okian.ro',E('https://www.okian.ro/catalogsearch/result/?q={q}'),/\.html/,1)];
const srcOn=s=>(S.vsrc||{})[s.id]===undefined?!!s.def:!!S.vsrc[s.id];
/* ---------- tropes ---------- */
const TR=[['Enemies to lovers','enemies[- ]to[- ]lovers|dusmani.{0,15}(iubit|indragost)'],['Friends to lovers','friends[- ]to[- ]lovers|prieteni.{0,10}iubit'],['Slow burn','slow[- ]burn'],['Fake dating','fake (dating|relationship|marriage|engagement)|pretend(ing)? (to be|dating)|casatorie fictiva'],['Forced proximity','forced proximity|stuck together|trapped together|one bed'],['Grumpy x sunshine','grumpy.{0,12}sunshine'],['Love triangle','love triangle|triunghi amoros'],['Second chance','second[- ]chance'],['Forbidden love','forbidden (love|romance)|iubire interzisa|dragoste interzisa'],['Arranged marriage','arranged marriage|casatorie aranjata'],['Found family','found family|familie aleasa'],['Chosen one','chosen one|the chosen|alesul|destined'],['Reluctant hero','reluctant hero'],['Coming of age','coming[- ]of[- ]age'],['Unreliable narrator','unreliable narrator'],['Time travel','time travel|time loop|calatorie in timp'],['Portal fantasy','portal fantasy|another world|alta lume'],['Magic school','magic(al)? school|school of magic|wizarding|scoala de magie'],['Dark academia','dark academia'],['Secret society','secret society|societate secreta'],['Heist','heist|jaf'],['Whodunit','whodunit|who dunnit|locked[- ]room'],['Cozy mystery','cozy mystery|cosy mystery'],['Serial killer','serial killer|ucigas in serie'],['Psychological thriller','psychological thriller|thriller psihologic'],['Twist ending','twist ending|plot twist|shocking twist|rasturnare de situatie'],['Anti-hero','anti-?hero|antierou'],['Morally grey','morally (grey|gray|ambiguous)|moral gri'],['Redemption arc','redemption'],['Revenge','revenge|razbunare'],['Rags to riches','rags to riches'],['Survival','survival|supravietuire'],['Post-apocalyptic','post-?apocalyptic|postapocaliptic|apocalypse'],['Dystopia','dystopi\\w*|distopi\\w*'],['Space opera','space opera'],['First contact','first contact'],['Artificial intelligence','artificial intelligence|inteligenta artificiala|sentient (ai|machine)'],['Vampires','vampires?|vampiri'],['Werewolves','werewol\\w+|vircolac\\w*'],['Haunted house','haunted (house|mansion)|casa bantuita'],['Small town','small[- ]town|oras mic'],['Epic quest','epic quest|\\bquest\\b|calatorie epica'],['Royalty','royal(ty)?|prince|princess|queen|king\\b|printes|regina'],['Hidden identity','hidden identity|secret identity|identitate ascunsa'],['Amnesia','amnesia'],['Dual timeline','dual timeline|two timelines|dual time'],['Epistolary','epistolary|letters and diary|scrisori'],['Mentor figure','mentor'],['Prophecy','prophecy|profetie'],['Dragons','dragons?|dragoni'],['War','\\bwar\\b|razboi'],['Political intrigue','political intrigue|court intrigue|intrigi politice'],['Found diary','found diary|hidden diary'],['Road trip','road trip'],['Desert','desert'],['Survivor guilt','survivor.s guilt']];
const TRX=TR.map(([n,r])=>[n,new RegExp('(^|[^a-z])(?:'+r+')([^a-z]|$)','i')]);
/* ---------- run + summarise ---------- */
const withTimeout=(p,ms)=>new Promise((res,rej)=>{const t=setTimeout(()=>rej(new Error('timeout')),ms);p.then(v=>{clearTimeout(t);res(v)},e=>{clearTimeout(t);rej(e)})});
function queryFor(b){const t=cleanTitle(b.title),a=authLast(b.author),short=toks(t).slice(0,7).join(' ');return{t:short||t,a,tt:toks(t),q:(short||t)+(a?' '+a:'')}}
async function runSource(s,q){const t0=Date.now();try{const r=await withTimeout(s.run(q),s.kind=='store'?16000:11000);if(!r)return{id:s.id,name:s.name,lang:s.lang,host:s.host,status:'none',ms:Date.now()-t0};
return{id:s.id,name:s.name,lang:s.lang,host:s.host,status:'ok',url:r.url,title:r.title,cats:cleanCats(r.cats,r.title||''),tags:r.tags||[],desc:r.desc||'',ms:Date.now()-t0}}
catch(e){const m=String(e&&e.message||e);return{id:s.id,name:s.name,lang:s.lang,host:s.host,status:/blocked/.test(m)?'blocked':'err',err:m,ms:Date.now()-t0}}}
function summarize(b,res){const votes={},tc={},tr={};let ok=0;const rows=[];
for(const r of res){if(r.status!='ok')continue;ok++;const cx=classifyEx(r.cats,'','');r.cat=cx.score>0?cx.cat:null;r.cscore=cx.score;if(r.cat)votes[r.cat]=(votes[r.cat]||0)+(cx.score>=3?1:.6);
const txt=norm([r.cats.join(' | '),r.tags.join(' | '),r.desc].join(' | '));for(const[n,rx]of TRX)if(rx.test(txt))(tr[n]=tr[n]||new Set()).add(r.id);
const cand=cleanTags([...r.tags,...r.cats.filter(c=>c.split(' ').length<=3)]);for(const t of new Set(cand.map(x=>norm(x))))if(t.length>2&&!CATS.some(c=>norm(c)==t))(tc[t]=tc[t]||{n:0,label:''}).n++;
for(const t of cand){const k=norm(t);if(tc[k]&&!tc[k].label)tc[k].label=t}}
const top=Object.entries(votes).sort((a,c)=>c[1]-a[1]),tot=top.reduce((a,x)=>a+x[1],0),agree=res.filter(r=>r.status=='ok'&&r.cat&&top[0]&&r.cat==top[0][0]).length;
const sum={ok,tried:res.length,cat:top[0]?top[0][0]:null,alt:top[1]?top[1][0]:null,conf:top[0]?top[0][1]/tot:0,agree,
tropes:Object.entries(tr).map(([n,s])=>[n,s.size]).filter(x=>x[1]>=1).sort((a,c)=>c[1]-a[1]).slice(0,14),
tags:Object.values(tc).filter(x=>x.label&&!TR.some(([n])=>norm(n)==norm(x.label))&&!(tr[x.label]||tr[TC(x.label)])).sort((a,c)=>c.n-a.n).slice(0,14).map(x=>[x.label,x.n])};
sum.strong=!!sum.cat&&((agree>=2&&sum.conf>=.6)||(ok==1&&agree==1&&res.find(r=>r.cat&&r.cscore>=3)));return sum}
const VC={};try{Object.assign(VC,JSON.parse(localStorage.getItem('nv_cache')||'{}'))}catch(e){}
const saveVC=()=>{try{const k=Object.keys(VC);if(k.length>300)k.slice(0,k.length-300).forEach(x=>delete VC[x]);localStorage.setItem('nv_cache',JSON.stringify(VC))}catch(e){}};
async function verifyBook(b,o={}){const q=queryFor(b),ro=looksRo(b);let list=SRC.filter(srcOn);
list.sort((x,y)=>(x.kind!='store'?0:1)-(y.kind!='store'?0:1)||((ro?x.lang=='ro':x.lang=='en')?0:1)-((ro?y.lang=='ro':y.lang=='en')?0:1));
const key=norm(q.q)+'|'+list.map(s=>s.id).join(',');const c=!o.fresh&&VC[key];if(c&&Date.now()-c.t<30*864e5){return{res:c.res,sum:summarize(b,c.res),cached:true}}
const res=[],pool=o.quick?3:5;let i=0,stop=false;
const worker=async()=>{while(!stop){const s=list[i++];if(!s)return;const r=await runSource(s,q);res.push(r);o.onProgress&&o.onProgress(r,res.length,list.length);
if(o.quick){const okc=res.filter(x=>x.status=='ok').length;if(okc>=5){const sm=summarize(b,res);if(sm.agree>=4)stop=true}}if(o.cancel&&o.cancel())stop=true}};
await Promise.all(Array.from({length:pool},worker));
res.sort((a,c)=>list.findIndex(s=>s.id==a.id)-list.findIndex(s=>s.id==c.id));
VC[key]={t:Date.now(),res:res.map(r=>({...r,desc:(r.desc||'').slice(0,600)}))};saveVC();return{res,sum:summarize(b,res)}}
