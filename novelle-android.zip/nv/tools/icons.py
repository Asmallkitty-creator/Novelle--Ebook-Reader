# Generates Android launcher icons from assets/icon-only.png (run from nv/ after `cap add android`)
import os,sys
from PIL import Image,ImageDraw,ImageFilter
src=Image.open('assets/icon-only.png').convert('RGB')
res='android/app/src/main/res'
D={'mdpi':1,'hdpi':1.5,'xhdpi':2,'xxhdpi':3,'xxxhdpi':4}
for k,m in D.items():
    d=f'{res}/mipmap-{k}';os.makedirs(d,exist_ok=True)
    s=int(48*m);ic=src.resize((s,s),Image.LANCZOS)
    r=ic.copy().convert('RGBA');mk=Image.new('L',(s*4,s*4),0);ImageDraw.Draw(mk).ellipse((0,0,s*4-1,s*4-1),fill=255);mk=mk.resize((s,s),Image.LANCZOS)
    rr=Image.new('RGBA',(s,s),(0,0,0,0));rr.paste(r,(0,0),mk);rr.save(f'{d}/ic_launcher_round.png')
    sq=Image.new('L',(s*4,s*4),0);ImageDraw.Draw(sq).rounded_rectangle((0,0,s*4-1,s*4-1),radius=s*4*.22,fill=255);sq=sq.resize((s,s),Image.LANCZOS)
    q=Image.new('RGBA',(s,s),(0,0,0,0));q.paste(ic,(0,0),sq);q.save(f'{d}/ic_launcher.png')
    f=int(108*m);inner=int(f*.66);fg=src.resize((inner,inner),Image.LANCZOS).convert('RGBA')
    fe=max(2,inner//12);a=Image.new('L',(inner,inner),255);dr=ImageDraw.Draw(a);dr.rectangle((0,0,inner-1,inner-1),outline=0,width=fe);a=a.filter(ImageFilter.GaussianBlur(fe*.9));fg.putalpha(a)
    c=Image.new('RGBA',(f,f),(0,0,0,0));c.paste(fg,((f-inner)//2,(f-inner)//2),fg);c.save(f'{d}/ic_launcher_foreground.png')
os.makedirs(f'{res}/values',exist_ok=True)
open(f'{res}/values/ic_launcher_background.xml','w').write('<?xml version="1.0" encoding="utf-8"?><resources><color name="ic_launcher_background">#0A0120</color></resources>')
os.makedirs(f'{res}/mipmap-anydpi-v26',exist_ok=True)
x='<?xml version="1.0" encoding="utf-8"?><adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android"><background android:drawable="@color/ic_launcher_background"/><foreground android:drawable="@mipmap/ic_launcher_foreground"/></adaptive-icon>'
for n in('ic_launcher','ic_launcher_round'):open(f'{res}/mipmap-anydpi-v26/{n}.xml','w').write(x)
print('icons ok')
