import base64,io,sys
from PIL import Image
d='/home/claude/proj/nv/dev/'
im=Image.open('/mnt/user-data/uploads/file_000000005f908210af5af90c3f5ac3da.png').convert('RGB').resize((128,128),Image.LANCZOS)
b=io.BytesIO();im.save(b,'JPEG',quality=88);logo='data:image/jpeg;base64,'+base64.b64encode(b.getvalue()).decode()
sh=open(d+'shell.html').read()
import json
cat=open(d+'catIcons.json').read()
js=''.join(open(d+f).read()+'\n' for f in ['core.js','reader.js','ui.js']).replace('__LOGO__',logo).replace('__CATICONS__',cat)
assert '</body>' not in js and '</script>' not in js
out=sh.replace('/*CSS*/',open(d+'style.css').read()).replace('__LOGO__',logo).replace('/*JS*/',js)+'</body></html>\n'
open('/home/claude/proj/nv/src/index.html','w').write(out);print(len(out)//1024,'KB')
