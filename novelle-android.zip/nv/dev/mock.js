/* Mock "internet" used ONLY by the preview page and tests (never shipped in the APK). */
const MOCKDB=[
{m:'glass desert',t:'The Glass Desert',a:'A. Verrin',en:['Science fiction','Dystopian fiction','Post-apocalyptic fiction'],ro:['Science Fiction & Fantasy','Science Fiction'],tags:['Desert','Found family','Survival','Space exploration'],desc:'In a post-apocalyptic desert, a reluctant hero and her found family cross the glass flats. A slow burn rivalry, a chosen one prophecy and a shocking twist ending.'},
{m:'ember ash',t:'Ember and Ash',a:'Lena Hollow',en:['Fantasy fiction','Epic fantasy','Dragons'],ro:['Literatură','Fantasy'],tags:['Dragons','Magic','Court intrigue'],desc:'An enemies to lovers romance between a dragon rider and a rival queen. Political intrigue, an epic quest and a prophecy.'},
{m:'letters harbour',t:'Letters from the Harbour',a:'J. Marlowe',en:['Historical fiction','Epistolary fiction','Sea stories'],ro:['Literatură','Ficțiune istorică'],tags:['Letters','Seafaring','Dual timeline'],desc:'An epistolary novel told in letters across two timelines. Second chance love in a small harbour town.'},
{m:'dune',t:'Dune',a:'Frank Herbert',en:['Science fiction','Fiction','Dune (Imaginary place)'],ro:['Science Fiction & Fantasy','Science Fiction'],tags:['Desert planet','Political intrigue','Prophecy'],desc:'A chosen one, a desert planet and political intrigue.'}];
function mockFind(q){const t=toks(q);return MOCKDB.find(d=>d.m.split(' ').every(w=>t.includes(w)))}
function installMock(){window.__MOCK=1;const R=(s,b,ct)=>({status:s,text:b,url:null,ct});
net.get=async function(url){await sleep(40+Math.random()*120);const u=new URL(url),h=u.host.replace(/^www\./,''),p=decodeURIComponent(u.pathname+u.search);
const PN=['title','q','search','SearchTerm','keywords','keyword','term','t','s','k','query','search_term'];let qs='';for(const k of PN){const v=u.searchParams.get(k);if(v){qs=v;break}}if(!qs)qs=p.split('/').pop();
const J=o=>({status:200,text:JSON.stringify(o),url});
if(h=='openlibrary.org'){const d=mockFind(qs);return J({docs:d?[{title:d.t,author_name:[d.a],key:'/works/OL1W',subject:[...d.en,...d.tags,'Accessible book','Protected DAISY','Fiction, general']}]:[]})}
if(h=='googleapis.com'){const q=u.searchParams.get('q')||'';const d=mockFind(q);return J({items:d?[{id:'g1',volumeInfo:{title:d.t,authors:[d.a],categories:[d.en[0].replace(/ fiction$/i,'')==d.en[0]?d.en[0]:'Fiction / '+d.en[0]],description:d.desc,infoLink:'https://books.google.com/books?id=g1'}}]:[]})}
if(h=='loc.gov'){const d=mockFind(qs);return J({results:d?[{title:d.t,url:'https://www.loc.gov/item/1/',subject:d.en.map(x=>x.toLowerCase()),description:[d.desc]}]:[]})}
if(h=='archive.org'){const q=u.searchParams.get('q')||'';const d=mockFind(q);return J({response:{docs:d?[{title:d.t,identifier:'mock1',subject:d.en.join('; ')}]:[]}})}
if(h=='wikidata.org'){const a=u.searchParams.get('action');if(a=='wbsearchentities'){const d=mockFind(u.searchParams.get('search')||'');return J({search:d?[{id:'Q1',label:d.t,description:'2020 science fiction novel'}]:[]})}
if(a=='wbgetentities'&&(u.searchParams.get('props')=='claims'))return J({entities:{Q1:{claims:{P136:[{mainsnak:{datavalue:{value:{id:'Q2'}}}},{mainsnak:{datavalue:{value:{id:'Q3'}}}}]}}}});
const d=MOCKDB[0];return J({entities:{Q2:{labels:{en:{value:'science fiction'}}},Q3:{labels:{en:{value:'dystopian fiction'}}}}})}
// stores
if(h=='emag.ro')return{status:403,text:'blocked',url};
if(h=='okian.ro')return{status:200,text:'<html><body><h1>Rezultate</h1><div class="p"><a href="/altceva.html">Cu totul altă carte</a></div></body></html>',url};
const prodRx=/\/carte\/|\/book\/show|\/work\/|\/dp\/|\/w\/|\/p\/books|\/product\/[^s]|\/bookshop\/product|\.html$|\/book\//;const isSearch=/search|cauta|cautare|browse|[?&](s|k|q|t|term|query|keyword|keywords|SearchTerm|search_term)=|\/s\//.test(url)&&!(prodRx.test(u.pathname)&&!/\/search|cauta/.test(u.pathname));
const d=mockFind(isSearch?qs:u.pathname.replace(/[-_\/.]/g,' '));const ro=/\.ro$/.test(h);
const slug=d.m.replace(/ /g,'-');const prod={'carturesti.ro':'/carte/'+slug+'-123','goodreads.com':'/book/show/123-'+slug,'librarything.com':'/work/123-'+slug,'barnesandnoble.com':'/w/'+slug+'/123','waterstones.com':'/book/'+slug+'/123','bookshop.org':'/p/books/'+slug+'/123','blackwells.co.uk':'/bookshop/product/'+slug+'-123','elefant.ro':'/'+slug+'_abc123.html','libris.ro':'/'+slug+'-abc123.html','bookzone.ro':'/carte/'+slug,'librarie.net':'/carte/'+slug,'humanitas.ro':'/carte/'+slug,'polirom.ro':'/carte/'+slug,'litera.ro':'/product/'+slug}[h]||('/carte/'+slug);
if(isSearch)return{status:200,text:`<html><body><nav><a href="/">Acasă</a><a href="/login">Cont</a></nav><div class="results"><div class="card"><a href="/altceva-999"><img alt="Cu totul altă carte"></a><span>Cu totul altă carte</span></div><div class="card"><a href="${prod}"><img alt="${d.t}"><span class="t">${d.t}</span></a><span class="au">${d.a}</span></div><div class="card"><a href="/third-1">Another unrelated title</a></div></div></body></html>`,url};
const crumbs=ro?['Acasă','Cărți',...d.ro]:['Home','Books',...d.en.slice(0,2)];
const ldBook={'@context':'https://schema.org','@type':'Book','name':d.t,'author':{'@type':'Person','name':d.a},'description':d.desc,'genre':ro?d.ro[d.ro.length-1]:d.en[0],'keywords':d.tags.join(', ')};
const ldBc={'@type':'BreadcrumbList','itemListElement':crumbs.map((c,i)=>({'@type':'ListItem','position':i+1,'name':c}))};
const gr=h=='goodreads.com'?`<div data-testid="genresList">${d.en.map(g=>`<a href="/genres/${g}">${g}</a>`).join('')}</div>`:'';
const lt=h=='librarything.com'?d.tags.map(t=>`<a href="/tag/${t}">${t}</a>`).join(''):'';
return{status:200,text:`<html><head><title>${d.t}</title><script type="application/ld+json">${JSON.stringify([ldBook,ldBc])}</script></head><body><h1>${d.t}</h1>${gr}${lt}</body></html>`,url}}}
