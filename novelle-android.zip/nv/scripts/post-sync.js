// Runs automatically after `npx cap sync` (Capacitor "capacitor:sync:after" hook).
// Copies Novelle's native folder plugin + launcher icons into the generated Android project.
const fs = require('fs'), path = require('path');
const root = process.env.CAPACITOR_ROOT_DIR || process.cwd();
const A = path.join(root, 'android');
const log = m => console.log('[novelle] ' + m);
function copyDir(s, d) {
  fs.mkdirSync(d, { recursive: true });
  for (const e of fs.readdirSync(s, { withFileTypes: true })) {
    const a = path.join(s, e.name), b = path.join(d, e.name);
    e.isDirectory() ? copyDir(a, b) : fs.copyFileSync(a, b);
  }
}
try {
  if (!fs.existsSync(A)) { log('no android folder yet, skipping'); process.exit(0); }
  const jd = path.join(A, 'app/src/main/java/com/novelle/reader');
  fs.mkdirSync(jd, { recursive: true });
  for (const f of ['NovelleFolderPlugin.java', 'MainActivity.java'])
    fs.copyFileSync(path.join(root, 'native', f), path.join(jd, f));
  log('native folder plugin installed');
  const res = path.join(A, 'app/src/main/res');
  // remove icon variants that would clash with our PNGs
  if (fs.existsSync(res)) for (const d of fs.readdirSync(res)) {
    if (!d.startsWith('mipmap')) continue;
    for (const f of fs.readdirSync(path.join(res, d)))
      if (/^ic_launcher.*\.(webp|xml)$/.test(f) && d !== 'mipmap-anydpi-v26') fs.unlinkSync(path.join(res, d, f));
  }
  copyDir(path.join(root, 'native/res'), res);
  log('launcher icons installed');
} catch (e) { console.error('[novelle] post-sync warning:', e); }
