package com.novelle.reader;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.util.Base64;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.PixelCopy;
import android.view.View;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import android.view.Window;
import android.view.WindowManager;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.activity.result.ActivityResult;
import androidx.documentfile.provider.DocumentFile;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

@CapacitorPlugin(name = "FolderScan")
public class FolderScanPlugin extends Plugin {

  @PluginMethod
  public void pick(PluginCall call) {
    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
    startActivityForResult(call, i, "picked");
  }

  @ActivityCallback
  private void picked(PluginCall call, ActivityResult r) {
    if (call == null) return;
    if (r.getResultCode() != Activity.RESULT_OK || r.getData() == null || r.getData().getData() == null) {
      call.reject("cancelled");
      return;
    }
    Uri u = r.getData().getData();
    try {
      getContext().getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
    } catch (Exception e) {}
    walk(call, u);
  }

  @PluginMethod
  public void scan(PluginCall call) {
    String s = call.getString("uri");
    if (s == null) { call.reject("no uri"); return; }
    walk(call, Uri.parse(s));
  }

  private void walk(PluginCall call, Uri tree) {
    try {
      JSArray files = new JSArray();
      DocumentFile root = DocumentFile.fromTreeUri(getContext(), tree);
      if (root != null) collect(root, files, 0);
      JSObject o = new JSObject();
      o.put("uri", tree.toString());
      o.put("files", files);
      call.resolve(o);
    } catch (Exception e) {
      call.reject(e.getMessage());
    }
  }

  private void collect(DocumentFile dir, JSArray out, int depth) throws Exception {
    if (depth > 12) return;
    for (DocumentFile f : dir.listFiles()) {
      if (f.isDirectory()) { collect(f, out, depth + 1); continue; }
      String n = f.getName();
      if (n == null) continue;
      String l = n.toLowerCase();
      if (l.endsWith(".epub") || l.endsWith(".pdf") || l.endsWith(".txt") || l.endsWith(".html") || l.endsWith(".htm") || l.endsWith(".cbz") || l.endsWith(".mobi") || l.endsWith(".azw3") || l.endsWith(".azw")) {
        JSObject o = new JSObject();
        o.put("uri", f.getUri().toString());
        o.put("name", n);
        o.put("size", f.length());
        out.put(o);
      }
    }
  }

  @PluginMethod
  public void read(PluginCall call) {
    try {
      Uri u = Uri.parse(call.getString("uri"));
      InputStream in = getContext().getContentResolver().openInputStream(u);
      ByteArrayOutputStream b = new ByteArrayOutputStream();
      byte[] buf = new byte[65536];
      int n;
      while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
      in.close();
      JSObject o = new JSObject();
      o.put("data", Base64.encodeToString(b.toByteArray(), Base64.NO_WRAP));
      call.resolve(o);
    } catch (Exception e) {
      call.reject(e.getMessage());
    }
  }

  @PluginMethod
  public void orient(PluginCall call) {
    final String m = call.getString("mode", "auto");
    getActivity().runOnUiThread(() -> getActivity().setRequestedOrientation(
      m.equals("portrait") ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
      : m.equals("landscape") ? ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
      : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED));
    call.resolve();
  }

  @PluginMethod
  public void brightness(PluginCall call) {
    final float v = call.getFloat("value", -1f);
    getActivity().runOnUiThread(() -> {
      WindowManager.LayoutParams lp = getActivity().getWindow().getAttributes();
      lp.screenBrightness = v;
      getActivity().getWindow().setAttributes(lp);
    });
    call.resolve();
  }

  @PluginMethod
  public void volkeys(PluginCall call) {
    MainActivity.volKeys = call.getBoolean("on", false);
    call.resolve();
  }

  @PluginMethod
  public void immersive(PluginCall call) {
    final boolean on = call.getBoolean("on", false);
    getActivity().runOnUiThread(() -> {
      Window w = getActivity().getWindow();
      WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
      if (on) {
        c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        c.hide(WindowInsetsCompat.Type.systemBars());
      } else {
        c.show(WindowInsetsCompat.Type.systemBars());
      }
    });
    call.resolve();
  }

  @PluginMethod
  public void share(PluginCall call) {
    Intent i = new Intent(Intent.ACTION_SEND);
    i.setType("text/plain");
    i.putExtra(Intent.EXTRA_TEXT, call.getString("text", ""));
    i.putExtra(Intent.EXTRA_SUBJECT, call.getString("title", ""));
    Intent c = Intent.createChooser(i, null);
    c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    getContext().startActivity(c);
    call.resolve();
  }

  @PluginMethod
  public void shareImage(PluginCall call) {
    try {
      byte[] b = Base64.decode(call.getString("data"), Base64.DEFAULT);
      File f = new File(getContext().getCacheDir(), "quote.png");
      FileOutputStream o = new FileOutputStream(f);
      o.write(b);
      o.close();
      Uri u = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", f);
      Intent i = new Intent(Intent.ACTION_SEND);
      i.setType("image/png");
      i.putExtra(Intent.EXTRA_STREAM, u);
      i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
      Intent c = Intent.createChooser(i, null);
      c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      getContext().startActivity(c);
      call.resolve();
    } catch (Exception e) {
      call.reject(e.getMessage());
    }
  }

  @PluginMethod
  public void pickOnly(PluginCall call) {
    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
    startActivityForResult(call, i, "pickedOnly");
  }

  @ActivityCallback
  private void pickedOnly(PluginCall call, ActivityResult r) {
    if (call == null) return;
    if (r.getResultCode() != Activity.RESULT_OK || r.getData() == null || r.getData().getData() == null) {
      call.reject("cancelled");
      return;
    }
    Uri u = r.getData().getData();
    try {
      getContext().getContentResolver().takePersistableUriPermission(u,
        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
    } catch (Exception e) {}
    JSObject o = new JSObject();
    o.put("uri", u.toString());
    call.resolve(o);
  }

  @PluginMethod
  public void writeText(PluginCall call) {
    try {
      DocumentFile root = DocumentFile.fromTreeUri(getContext(), Uri.parse(call.getString("uri")));
      String name = call.getString("name");
      DocumentFile f = root.findFile(name);
      if (f == null) f = root.createFile("application/json", name);
      OutputStream o = getContext().getContentResolver().openOutputStream(f.getUri(), "wt");
      o.write(call.getString("text", "").getBytes("UTF-8"));
      o.close();
      call.resolve();
    } catch (Exception e) {
      call.reject(String.valueOf(e.getMessage()));
    }
  }

  @PluginMethod
  public void readText(PluginCall call) {
    try {
      DocumentFile root = DocumentFile.fromTreeUri(getContext(), Uri.parse(call.getString("uri")));
      DocumentFile f = root.findFile(call.getString("name"));
      if (f == null) { call.reject("not found"); return; }
      InputStream in = getContext().getContentResolver().openInputStream(f.getUri());
      ByteArrayOutputStream b = new ByteArrayOutputStream();
      byte[] buf = new byte[65536];
      int n;
      while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
      in.close();
      JSObject o = new JSObject();
      o.put("text", new String(b.toByteArray(), "UTF-8"));
      call.resolve(o);
    } catch (Exception e) {
      call.reject(String.valueOf(e.getMessage()));
    }
  }

  @PluginMethod
  public void snap(final PluginCall call) {
    if (Build.VERSION.SDK_INT < 26) { call.reject("api"); return; }
    getActivity().runOnUiThread(() -> {
      try {
        View v = getBridge().getWebView();
        int[] loc = new int[2];
        v.getLocationInWindow(loc);
        final int w = v.getWidth(), h = v.getHeight();
        final Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        PixelCopy.request(getActivity().getWindow(), new Rect(loc[0], loc[1], loc[0] + w, loc[1] + h), bmp, r -> {
          if (r == PixelCopy.SUCCESS) {
            Bitmap s = Bitmap.createScaledBitmap(bmp, (int) (w * 0.75f), (int) (h * 0.75f), true);
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            s.compress(Bitmap.CompressFormat.JPEG, 80, o);
            JSObject res = new JSObject();
            res.put("data", Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP));
            call.resolve(res);
          } else {
            call.reject("pixelcopy " + r);
          }
        }, new Handler(Looper.getMainLooper()));
      } catch (Exception e) {
        call.reject(String.valueOf(e.getMessage()));
      }
    });
  }
}
