package com.novelle.reader;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(NovelleFolderPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
